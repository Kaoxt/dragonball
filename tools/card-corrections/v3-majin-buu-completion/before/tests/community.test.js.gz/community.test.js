import {decksRequest} from '../src/community/decks-api.js';
import { avatarRequest, AVATAR_LIMIT } from '../src/community/avatar-upload.js';
import { forumImageRequest, FORUM_IMAGE_LIMIT } from '../src/community/forum-images.js';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { authSchema,authRequest } from '../src/community/auth.js';
import { forumDb } from '../src/community/forum.js';
import { onRequestGet,onRequestPost } from '../src/community/forum-api.js';
import { database } from '../src/community/database.js';
import { hash } from '../src/community/session.js';
import { migrateKurtUsername, migrateKaoxtIdentity, grantKaoxtAdministrator } from '../src/community/account-migrations.js';
import { recordTopicView } from '../src/community/topic-views.js';
function storage(){const db=new DatabaseSync(':memory:');return {sql:{exec(query,...args){const p=db.prepare(query);let values;try{values=p.all(...args);}catch(e){throw e;}return {toArray:()=>values};}},transactionSync(fn){db.exec('SAVEPOINT tx');try{const r=fn();db.exec('RELEASE tx');return r;}catch(e){db.exec('ROLLBACK TO tx; RELEASE tx');throw e;}}};}
async function fixture(){const env={DB:database(storage()),OWNER_SETUP_HASH:hash('test-owner-code')};authSchema(env.DB);await forumDb(env);const cookies={};return {env,cookies,async auth(who,action,data,origin='https://dragonball.test'){const request=new Request('https://dragonball.test/api/auth/'+action,{method:data?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json','CF-Connecting-IP':who,Cookie:cookies[who]||''},...(data?{body:JSON.stringify(data)}:{})});const r=await authRequest(request,env);const cookie=r.headers.get('set-cookie');if(cookie)cookies[who]=cookie.split(';')[0];return {status:r.status,data:await r.json(),cookie};},async forum(who,data,params={},origin='https://dragonball.test'){const request=new Request('https://dragonball.test/api/forum?'+new URLSearchParams(params),{method:data?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json',Cookie:cookies[who]||''},...(data?{body:JSON.stringify(data)}:{})});const r=await(data?onRequestPost:onRequestGet)({env,request});return {status:r.status,data:await r.json()};},async register(who){const r=await this.auth(who,'register',{username:who,password:'My private password 123!'});assert.equal(r.status,201,JSON.stringify(r));return r;}};}
const topic={action:'topic',categoryId:1,title:'My first Dragon Ball deck',body:'What do you think of this deck?'};
test('card finish belongs to the account, survives a new session, and rejects foreign writes', async () => {
 const f=await fixture();await f.register('alice');await f.register('bob');
 const initial=await f.auth('alice','card-finish');
 assert.equal(initial.data.finish,'foil');
 const userId=initial.data.userId;
 assert.equal((await f.auth('alice','card-finish',{userId,finish:'regular'})).status,200);
 assert.equal((await f.auth('alice','card-finish')).data.finish,'regular');
 assert.equal((await f.auth('bob','card-finish')).data.finish,'foil');
 assert.equal((await f.auth('bob','card-finish',{userId,finish:'regular'})).status,409);
 assert.equal((await f.auth('guest','card-finish',{userId,finish:'regular'})).status,401);
 assert.equal((await f.auth('alice','card-finish',{userId,finish:'invalid'})).status,400);
 assert.equal((await f.auth('alice','card-finish',{userId,finish:'foil'},'https://evil.test')).status,403);
 await f.auth('new-device','login',{username:'alice',password:'My private password 123!'});
 assert.equal((await f.auth('new-device','card-finish')).data.finish,'regular');
 await f.auth('alice','profile',{displayName:'Alice updated'});
 assert.equal((await f.auth('alice','card-finish')).data.finish,'regular');
 authSchema(f.env.DB);
 assert.equal((await f.auth('alice','card-finish')).data.finish,'regular','schema is safe to repeat');
 await f.auth('new-device','card-finish',{userId,finish:'foil'});
 assert.equal((await f.auth('alice','card-finish')).data.finish,'foil');
 assert.deepEqual((await f.auth('guest','card-finish')).data,{userId:null,finish:'foil'});
});
test('Turnstile protects login and recovery before session or password changes',async t=>{
 const f=await fixture(),created=await f.register('alice');
 const oldCookie=f.cookies.alice;
 f.env.TURNSTILE_SITE_KEY='public-site-key';f.env.TURNSTILE_SECRET_KEY='private-server-key';
 let result={success:true,hostname:'dragonball.test',action:'login'};
 t.mock.method(globalThis,'fetch',async()=>Response.json(result));
 const login={username:'alice',password:'My private password 123!'};
 const recover={username:'alice',password:'Replacement password 123!',recoveryCode:created.data.recoveryCode};
 const before=f.env.DB.prepare('SELECT password_version FROM auth_accounts').first().password_version;
 for(const action of ['login','recover']){
  const data=action==='login'?login:recover;
  assert.equal((await f.auth(action+'missing',action,data)).status,400);
  result={success:true,hostname:'dragonball.test',action:'register'};
  assert.equal((await f.auth(action+'wrongaction',action,{...data,'cf-turnstile-response':'token'})).status,400);
  result={success:true,hostname:'other.test',action};
  assert.equal((await f.auth(action+'wronghost',action,{...data,'cf-turnstile-response':'token'})).status,400);
  result={success:false,'error-codes':['timeout-or-duplicate']};
  assert.equal((await f.auth(action+'replayed',action,{...data,'cf-turnstile-response':'token'})).status,400);
 }
 assert.equal(f.env.DB.prepare('SELECT password_version FROM auth_accounts').first().password_version,before);
 assert.equal(f.env.DB.prepare('SELECT COUNT(*) AS n FROM auth_sessions').first().n,1);
 result={success:true,hostname:'dragonball.test',action:'login'};
 assert.equal((await f.auth('validlogin','login',{...login,'cf-turnstile-response':'token'})).status,200);
 result={success:true,hostname:'dragonball.test',action:'recover'};
 assert.equal((await f.auth('validrecover','recover',{...recover,'cf-turnstile-response':'token'})).status,200);
 f.cookies.alice=oldCookie;
 assert.equal((await f.auth('alice','session')).data.user,null);
 assert.equal(f.env.DB.prepare('SELECT password_version FROM auth_accounts').first().password_version,before+1);
});
test('topic views count visits, deduplicate refreshes, and ignore pagination and hidden topics',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 const id=(await f.forum('alice',topic)).data.id;
 assert.equal((await f.forum(null,null,{view:'topic',id})).data.topic.view_count,1);
 assert.equal((await f.forum(null,null,{view:'topic',id})).data.topic.view_count,1);
 assert.equal((await f.forum('bob',null,{view:'topic',id,after:1})).data.topic.view_count,1);
 assert.equal((await f.forum('bob',null,{view:'topic',id})).data.topic.view_count,2);
 assert.equal((await f.forum(null,null,{view:'list'})).data.topics[0].view_count,2);
 const member=(await f.auth('bob','session')).data.user,request=new Request('https://dragonball.test/');
 assert.equal(recordTopicView(f.env.DB,request,member,id,Date.now()+1800001),3);
 await f.auth('alice','claim-owner',{code:'test-owner-code'});
 f.env.DB.prepare('UPDATE forum_topics SET hidden=1 WHERE id=?').bind(id).run();
 assert.equal((await f.forum(null,null,{view:'topic',id})).status,404);
 assert.equal((await f.forum('alice',null,{view:'topic',id})).data.topic.view_count,3);
});
test('topic rows use the latest visible poster and preserve the original creation date',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 const id=(await f.forum('alice',topic)).data.id;
 const original=(await f.forum(null,null,{view:'list'})).data.topics[0];
 assert.equal(original.latest_author,'alice');assert.equal(original.latest_reply_id,null);
 await f.auth('bob','profile',{displayName:'Bob',avatarUrl:'https://example.com/bob.png'});
 await f.forum('bob',{action:'reply',id,body:'Latest reply.'});
 const latest=(await f.forum(null,null,{view:'list'})).data.topics[0];
 assert.equal(latest.latest_author,'Bob');assert.equal(latest.latest_avatar_url,'https://example.com/bob.png');assert.ok(latest.latest_reply_id);
 assert.equal(latest.created_at,original.created_at);assert.equal(latest.author,'alice');
 f.env.DB.prepare('UPDATE forum_replies SET hidden=1 WHERE id=?').bind(latest.latest_reply_id).run();
 const hidden=(await f.forum(null,null,{view:'list'})).data.topics[0];
 assert.equal(hidden.latest_author,'alice');assert.equal(hidden.latest_reply_id,null);
});
test('requested login rename preserves identity and credentials and runs only once',async()=>{
 const f=await fixture();await f.register('kaoxt');
 const before=(await f.auth('kaoxt','session')).data.user;
 f.env.DB.prepare('UPDATE forum_members SET id=? WHERE user_id=?').bind('7bb24f5c-1f13-4bfc-af60-c153f980e9af',before.id).run();
 const credentials=f.env.DB.prepare('SELECT * FROM auth_accounts WHERE id=?').bind(before.id).first();
 const post=(await f.forum('kaoxt',topic)).data.id;
 assert.equal(migrateKurtUsername(f.env.DB),'renamed');
 assert.deepEqual({...f.env.DB.prepare('SELECT * FROM auth_accounts WHERE id=?').bind(before.id).first()},{...credentials,username:'Kurt'});
 assert.equal((await f.auth('kaoxt','session')).data.user.id,before.id);
 assert.equal((await f.forum('kaoxt',{action:'topicEdit',id:post,title:'Still my post',body:'Same account.'})).status,200);
 assert.equal((await f.auth('new-session','login',{username:'Kurt',password:'My private password 123!'})).status,200);
 assert.equal((await f.auth('old-name','login',{username:'kaoxt',password:'My private password 123!'})).status,401);
 assert.equal(migrateKurtUsername(f.env.DB),'completed');
});
test('login rename does not affect other identities or take an occupied username',async()=>{
 const f=await fixture();await f.register('kaoxt');await f.register('kurt');
 const account=(await f.auth('kaoxt','session')).data.user;
 f.env.DB.prepare('UPDATE forum_members SET id=? WHERE user_id=?').bind('7bb24f5c-1f13-4bfc-af60-c153f980e9af',account.id).run();
 assert.equal(migrateKurtUsername(f.env.DB),'conflict');
 assert.equal((await f.auth('kaoxt','session')).data.user.username,'kaoxt');
 const other=await fixture();await other.register('kaoxt');
 assert.equal(migrateKurtUsername(other.env.DB),'not-applicable');
 assert.equal((await other.auth('kaoxt','session')).data.user.username,'kaoxt');
});
test('accounts: registration, secure cookie, login, no leaked password/recovery, logout',async()=>{
 const f=await fixture();const created=await f.register('alice');assert.match(created.data.recoveryCode,/^[a-f0-9]{64}$/);assert.match(created.cookie,/HttpOnly; SameSite=Lax/);assert.match(created.cookie,/Secure/);
 const self=await f.auth('alice','session');assert.equal(self.data.user.username,'alice');assert.equal(self.data.user.isAdmin,false);assert.ok(self.data.user.memberId);assert.doesNotMatch(JSON.stringify(self),/password|recovery_hash/);
 assert.equal((await f.auth('bob','login',{username:'alice',password:'bad'})).status,401);
 assert.equal((await f.auth('bob','register',{username:'ALICE',password:'My private password 123!'})).status,409);
 const stolen=f.cookies.alice;await f.auth('alice','logout',{});f.cookies.bob=stolen;assert.equal((await f.auth('bob','session')).data.user,null);
 assert.equal((await f.auth('alice','login',{username:'alice',password:'My private password 123!'})).status,200);
});
test('password recovery rotates code, revokes sessions, requires new password',async()=>{
 const f=await fixture(),r=await f.register('alice');const original=f.cookies.alice;
 assert.equal((await f.auth('bob','recover',{username:'alice',recoveryCode:'bad',password:'My replacement password'})).status,401);
 const recovered=await f.auth('bob','recover',{username:'alice',recoveryCode:r.data.recoveryCode,password:'My replacement password'});assert.equal(recovered.status,200);assert.notEqual(recovered.data.recoveryCode,r.data.recoveryCode);
 f.cookies.alice=original;assert.equal((await f.auth('alice','session')).data.user,null);
 assert.equal((await f.auth('carol','recover',{username:'alice',recoveryCode:r.data.recoveryCode,password:'Third private password'})).status,401);
 assert.equal((await f.auth('alice','login',{username:'alice',password:'My replacement password'})).status,200);
 const other=await f.auth('carol','login',{username:'alice',password:'My replacement password'});assert.equal(other.status,200);
 const changed=await f.auth('alice','password',{currentPassword:'My replacement password',password:'Third private password'});assert.equal(changed.status,200);assert.equal((await f.auth('carol','session')).data.user,null);assert.equal((await f.auth('alice','session')).data.user.username,'alice');
});
test('owner access is token-protected, one-time, and not assigned to first signup',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 assert.equal((await f.forum('alice',null,{view:'admin'})).status,403);
 assert.equal((await f.auth('alice','claim-owner',{code:'wrong'})).status,403);
 assert.equal((await f.auth('alice','claim-owner',{code:'test-owner-code'})).status,200);
 assert.equal((await f.auth('alice','session')).data.user.isAdmin,true);
 assert.equal((await f.auth('bob','claim-owner',{code:'test-owner-code'})).status,409);
 assert.equal((await f.forum('alice',null,{view:'admin'})).status,200);
});
test('CSRF, validation, and persistent brute-force limits',async()=>{
 const f=await fixture();assert.equal((await f.auth('alice','register',{username:'alice',password:'My private password 123!'},'https://evil.test')).status,403);
 assert.equal((await f.auth('alice','register',{username:'alice',password:'short'})).status,400);
 for(let i=0;i<10;i++)assert.equal((await f.auth('attacker','login',{username:'missing',password:'wrong'})).status,401);
 assert.equal((await f.auth('attacker','login',{username:'missing',password:'wrong'})).status,429);
});
test('posting, replies, likes, follows, profile, mentions and notification ownership',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 assert.equal((await f.forum(null,topic)).status,401);assert.equal((await f.forum('alice',topic,{},'https://evil.test')).status,403);
 const b=(await f.auth('bob','session')).data.user;
 const created=await f.forum('alice',{...topic,body:`Hello @[bob](member:${b.memberId})!`,author:'fake',role:'admin'});assert.equal(created.status,201,JSON.stringify(created));const id=created.data.id;
 const detail=await f.forum(null,null,{view:'topic',id});assert.equal(detail.data.topic.author,'alice');assert.doesNotMatch(JSON.stringify(detail),/password|user_id|recovery/);
 assert.equal((await f.forum('bob',{action:'reply',id,body:'Great deck!'})).status,201);
 assert.equal((await f.forum('bob',{action:'like',kind:'topic',id,liked:true})).status,200);assert.equal((await f.forum('alice',{action:'like',kind:'topic',id,liked:true})).status,403);
 const likedDetail=(await f.forum(null,null,{view:'topic',id})).data;
 assert.equal(likedDetail.topic.likes_received,1);assert.equal(likedDetail.topic.post_count,1);
 assert.equal(likedDetail.replies[0].likes_received,0);assert.equal(likedDetail.replies[0].post_count,1);
 const unliked=await f.forum('bob',{action:'like',kind:'topic',id,liked:false});
 assert.equal(unliked.data.likes_received,0);assert.equal((await f.forum(null,null,{view:'topic',id})).data.topic.likes_received,0);
 await f.forum('bob',{action:'follow',id,following:true});assert.equal((await f.forum('bob',null,{view:'followed'})).data.topics.length,1);
 const notices=await f.forum('bob',null,{view:'notifications'});assert.equal(notices.data.unreadCount,1);assert.match(notices.data.notifications[0].url,/^\/forums\/#topic/);assert.equal((await f.forum('alice',null,{view:'notifications'})).data.unreadCount,0);
 await f.auth('bob','profile',{displayName:'Vegeta fan',about:'I play Saiyan decks.',avatarUrl:'https://example.com/avatar.webp'});
 const member=await f.forum(null,null,{view:'member',id:b.memberId});assert.equal(member.data.member.author,'Vegeta fan');assert.equal(member.data.member.reply_count,1);
 assert.equal((await f.auth('bob','profile',{displayName:'Bad avatar',avatarUrl:'javascript:alert(1)'})).status,400);
});
test('member ownership, 24-hour editing, admin-only delete, moderation and locked replies',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');await f.register('owner');await f.auth('owner','claim-owner',{code:'test-owner-code'});
 assert.equal((await f.forum('alice',{...topic,categoryId:4})).status,403);
 const id=(await f.forum('alice',topic)).data.id;
 const edit={action:'topicEdit',id,title:'Updated deck title',body:'Updated explanation'};
 assert.equal((await f.forum('bob',edit)).status,403);assert.equal((await f.forum('alice',edit)).status,200);
 f.env.DB.prepare('UPDATE forum_topics SET created_at=? WHERE id=?').bind(new Date(Date.now()-90000000).toISOString(),id).run();assert.equal((await f.forum('alice',edit)).status,403);assert.equal((await f.forum('owner',edit)).status,200);
 assert.equal((await f.forum('alice',{action:'topicDelete',id})).status,403);
 const mod={action:'topicModerate',id,categoryId:1,pinned:true,locked:true,hidden:false};assert.equal((await f.forum('owner',mod)).status,200);assert.equal((await f.forum('bob',{action:'reply',id,body:'Blocked'})).status,409);
 await f.forum('owner',{...mod,hidden:true});assert.equal((await f.forum(null,null,{view:'topic',id})).status,404);
 assert.equal((await f.forum('owner',{action:'topicDelete',id})).status,200);
});
test('SQL batch rollback and 25-topic pagination',async()=>{
 const f=await fixture();await f.register('alice');const m=(await f.auth('alice','session')).data.user.memberId;
 assert.throws(()=>f.env.DB.batch([f.env.DB.prepare("INSERT INTO auth_settings(key,value) VALUES('rollback','yes')"),f.env.DB.prepare('INSERT INTO nonexistent_table VALUES(1)')]));assert.equal(f.env.DB.prepare("SELECT value FROM auth_settings WHERE key='rollback'").first(),null);
 for(let i=0;i<26;i++)f.env.DB.prepare('INSERT INTO forum_topics(member_id,category_id,title,body,created_at,updated_at) VALUES(?,1,?,?,?,?)').bind(m,'Topic '+i,'A body',new Date().toISOString(),new Date().toISOString()).run();
 assert.equal((await f.forum(null,null,{view:'list'})).data.topics.length,25);assert.equal((await f.forum(null,null,{view:'list',page:2})).data.topics.length,1);
});

test('Turnstile registration: config privacy, fail-closed verification, hostname/action, replay and outage',async t=>{
 const f=await fixture();
 assert.deepEqual((await f.auth('guest','config')).data.turnstile,{required:false,ready:false,siteKey:''});
 f.env.TURNSTILE_SITE_KEY='public-site-key';
 const registration={username:'protected',password:'A private registration password'};
 assert.equal((await f.auth('partial','register',registration)).status,503);
 f.env.TURNSTILE_SECRET_KEY='private-server-key';
 const config=await f.auth('guest','config');assert.deepEqual(config.data.turnstile,{required:true,ready:true,siteKey:'public-site-key'});assert.doesNotMatch(JSON.stringify(config),/private-server-key/);
 let calls=0,result={success:true,hostname:'dragonball.test',action:'register'};
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  calls++;assert.equal(url,'https://challenges.cloudflare.com/turnstile/v0/siteverify');
  const data=JSON.parse(options.body);assert.equal(data.secret,'private-server-key');assert.equal(data.response,'challenge-token');assert.ok(options.signal);
  return Response.json(result);
 });
 assert.equal((await f.auth('missing','register',registration)).status,400);
 assert.equal((await f.auth('oversize','register',{...registration,'cf-turnstile-response':'a'.repeat(2049)})).status,400);assert.equal(calls,0);
 const verified={...registration,'cf-turnstile-response':'challenge-token'};
 result={success:false,'error-codes':['timeout-or-duplicate']};assert.equal((await f.auth('invalid','register',verified)).status,400);
 result={success:true,hostname:'evil.test',action:'register'};assert.equal((await f.auth('wronghost','register',verified)).status,400);
 result={success:true,hostname:'dragonball.test',action:'login'};assert.equal((await f.auth('wrongaction','register',verified)).status,400);
 assert.equal(f.env.DB.prepare('SELECT count(*) AS n FROM auth_accounts').first().n,0);
 result={success:true,hostname:'dragonball.test',action:'register'};assert.equal((await f.auth('valid','register',verified)).status,201);
 result={success:false,'error-codes':['timeout-or-duplicate']};assert.equal((await f.auth('replay','register',{...verified,username:'replayed'})).status,400);
 t.mock.method(globalThis,'fetch',async()=>{throw Error('network down');});
 assert.equal((await f.auth('outage','register',{...verified,username:'outage'})).status,503);
 assert.equal(f.env.DB.prepare('SELECT count(*) AS n FROM auth_accounts').first().n,1);
 assert.equal((await f.auth('valid','login',{username:'protected',password:registration.password})).status,400);
});

test('avatar uploads enforce size, ownership and origin and appear in profiles',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP1sAAAAASUVORK5CYII=','base64');
 const upload=(who,bytes=png,origin='https://dragonball.test')=>avatarRequest(new Request('https://dragonball.test/api/auth/avatar',{method:'POST',headers:{Origin:origin,Cookie:f.cookies[who]||'','Content-Type':'image/png'},body:bytes}),f.env);
 assert.equal((await upload(null)).status,401);
 assert.equal((await upload('alice',png,'https://evil.test')).status,403);
 assert.equal((await upload('alice',Buffer.from('<svg onload="alert(1)"/>'))).status,400);
 assert.equal((await upload('alice',Buffer.alloc(AVATAR_LIMIT+1))).status,413);
 const response=await upload('alice');assert.equal(response.status,200);const {avatarUrl}=await response.json();
 const image=await avatarRequest(new Request('https://dragonball.test'+avatarUrl),f.env);
 assert.equal(image.headers.get('Content-Type'),'image/png');assert.deepEqual(Buffer.from(await image.arrayBuffer()),png);
 assert.equal((await f.auth('alice','session')).data.user.avatarUrl,avatarUrl);
 const id=(await f.forum('alice',topic)).data.id;assert.equal((await f.forum(null,null,{view:'topic',id})).data.topic.avatar_url,avatarUrl);
 await f.auth('alice','profile',{displayName:'Alice',about:'Hello',avatarUrl:''});
 assert.equal((await f.auth('alice','session')).data.user.avatarUrl,avatarUrl);
 const remove=who=>avatarRequest(new Request('https://dragonball.test/api/auth/avatar-remove',{method:'POST',headers:{Origin:'https://dragonball.test',Cookie:f.cookies[who]}}),f.env);
 await remove('bob');assert.equal((await f.auth('alice','session')).data.user.avatarUrl,avatarUrl);
 await remove('alice');assert.equal((await f.auth('alice','session')).data.user.avatarUrl,'');
 assert.equal((await avatarRequest(new Request('https://dragonball.test'+avatarUrl),f.env)).status,404);
});

test('account decks are private, persistent, origin-checked and versioned',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 const call=async(who,data,origin='https://dragonball.test')=>{const r=await decksRequest(new Request('https://dragonball.test/api/decks',{method:data?'POST':'GET',headers:{Cookie:f.cookies[who]||'',Origin:origin,'Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})}),f.env);return {status:r.status,data:await r.json()};};
 assert.equal((await call(null)).status,401);
 const first=(await call('alice')).data;assert.equal(first.version,0);
 const deck={id:'test-deck',name:'My deck',tokui:'Black',personalities:[null,null,null,null,null],cards:[],senseiDeck:[],mastery:null,sensei:null};
 const payload={userId:first.userId,version:0,data:{decks:[deck],active:deck.id}};
 assert.equal((await call(null,payload)).status,401);
 f.cookies.expired='dragon_session='+'a'.repeat(64);
 assert.equal((await call('expired',payload)).status,401);
 assert.equal((await call('alice',payload,'https://evil.test')).status,403);
 assert.equal((await call('bob',payload)).status,409);
 assert.equal((await call('alice',payload)).status,200);
 assert.equal((await call('alice')).data.data.decks[0].name,'My deck');
 assert.equal((await call('bob')).data.data.decks.length,0);
 assert.equal((await call('alice',payload)).status,409);
 assert.equal((await call('alice',{...payload,version:1,data:{decks:[],active:null}})).status,200);
 assert.equal((await call('alice')).data.data.decks.length,0);
});

test('private messages require login, isolate conversations, and mark only received messages read',async()=>{
 const f=await fixture();for(const name of ['alice','bob','charlie'])await f.register(name);
 const member=async who=>(await f.auth(who,'session')).data.user.memberId;
 const a=await member('alice'),b=await member('bob'),c=await member('charlie');
 assert.equal((await f.forum(null,null,{view:'messages'})).status,401);
 const sent=await f.forum('alice',{action:'messageSend',member:b,body:'Private deck advice'});assert.equal(sent.status,201,JSON.stringify(sent));
 assert.equal((await f.forum('bob',null,{view:'alerts'})).data.messages,1);
 assert.equal((await f.forum('alice',null,{view:'messages'})).data.conversations[0].member_id,b);
 assert.equal((await f.forum('bob',null,{view:'messages',member:a})).data.messages[0].body,'Private deck advice');
 assert.equal((await f.forum('charlie',null,{view:'messages',member:a})).data.messages.length,0);
 assert.equal((await f.forum('charlie',null,{view:'messages',member:b})).data.messages.length,0);
 await f.forum('charlie',{action:'messagesRead',member:a,through:sent.data.id});
 assert.equal((await f.forum('bob',null,{view:'alerts'})).data.messages,1);
 await f.forum('bob',{action:'messagesRead',member:a,through:sent.data.id});
 assert.equal((await f.forum('bob',null,{view:'alerts'})).data.messages,0);
 assert.equal((await f.forum('alice',{action:'messageSend',member:a,body:'Self'})).status,400);
 f.env.DB.prepare('UPDATE forum_members SET banned=1 WHERE id=?').bind(c).run();
 assert.equal((await f.forum('alice',{action:'messageSend',member:c,body:'Blocked'})).status,404);
 assert.equal((await f.forum('charlie',{action:'messageSend',member:a,body:'Blocked'})).status,403);
 assert.equal((await f.forum('alice',{action:'messageSend',member:b,body:'Bad origin'},{},'https://evil.test')).status,403);
});
test('linked quotes notify the original author, deduplicate mentions, and skip hidden sources',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 const t=(await f.forum('alice',topic)).data.id;
 const a=(await f.auth('alice','session')).data.user.memberId;
 const body=`> [alice wrote:](/forums/#topic/${t})\n> What do you think?\n\nGood idea @[alice](member:${a})`;
 const r=await f.forum('bob',{action:'reply',id:t,body});assert.equal(r.status,201,JSON.stringify(r));
 const n=(await f.forum('alice',null,{view:'notifications'})).data;
 assert.equal(n.unreadCount,1);assert.equal(n.notifications[0].replyId,r.data.id);
 assert.equal(n.notifications[0].url,`/forums/#topic/${t}?reply=${r.data.id}`);
 const self=await f.forum('alice',{action:'reply',id:t,body});assert.equal(self.status,201);
 assert.equal((await f.forum('alice',null,{view:'notifications'})).data.unreadCount,1);
 const other=(await f.forum('bob',topic)).data.id;
 f.env.DB.prepare('UPDATE forum_topics SET hidden=1 WHERE id=?').bind(t).run();
 await f.forum('bob',{action:'reply',id:other,body:`> [alice wrote:](/forums/#topic/${t})\n> Hidden post\n\nTest`});
 assert.equal(f.env.DB.prepare('SELECT COUNT(*) AS n FROM forum_notifications').first().n,1);
});


test('News imports the three original articles as Kurt once and shares announcement replies',async()=>{
 const f=await fixture();
 assert.equal((await f.forum(null,null,{view:'news'})).data.articles.length,0);
 await f.register('kaoxt');await f.auth('kaoxt','claim-owner',{code:'test-owner-code'});
 const account=(await f.auth('kaoxt','session')).data.user;
 f.env.DB.prepare('UPDATE forum_members SET id=? WHERE user_id=?').bind('7bb24f5c-1f13-4bfc-af60-c153f980e9af',account.id).run();
 await f.auth('kaoxt','profile',{displayName:'Kurt'});
 const news=(await f.forum(null,null,{view:'news'})).data.articles;
 assert.equal(news.length,3);assert.ok(news.every(t=>t.author==='Kurt'));
 assert.equal(news[0].title,'A place to build your next deck.');
 assert.equal((await f.forum(null,null,{view:'news'})).data.articles.length,3);
 await f.register('reader');
 assert.equal((await f.forum('reader',{action:'topic',categoryId:4,title:'Unauthorized announcement',body:'No.'})).status,403);
 assert.equal((await f.forum(null,{action:'reply',id:news[0].id,body:'Anonymous comment'})).status,401);
 assert.equal((await f.forum('reader',{action:'reply',id:news[0].id,body:'Shared comment from News'})).status,201);
 const detail=(await f.forum(null,null,{view:'newsTopic',id:news[0].id})).data;
 assert.equal(detail.replies[0].body,'Shared comment from News');
 assert.equal((await f.forum(null,null,{view:'topic',id:news[0].id})).data.replies[0].id,detail.replies[0].id);
 const fresh=await f.forum('kaoxt',{action:'topic',categoryId:4,title:'A new announcement',body:'Automatically in News.'});
 assert.equal((await f.forum(null,null,{view:'news'})).data.articles[0].id,fresh.data.id);
 await f.forum('kaoxt',{action:'topicDelete',id:news[1].id});
 assert.equal((await f.forum(null,null,{view:'news'})).data.articles.length,3);
 assert.equal((await f.forum(null,null,{view:'news'})).data.articles.some(t=>t.id===news[1].id),false);
 await f.forum('kaoxt',{action:'topicModerate',id:fresh.data.id,categoryId:4,hidden:true,locked:false,pinned:false});
 assert.equal((await f.forum(null,null,{view:'news'})).data.articles.some(t=>t.id===fresh.data.id),false);
});

test('News loads five visible stories per batch and only offers more when another exists',async()=>{
 const f=await fixture();await f.register('alice');
 const member=f.env.DB.prepare('SELECT id FROM forum_members').first().id;
 const add=(title,hidden=0)=>f.env.DB.prepare('INSERT INTO forum_topics(member_id,category_id,title,body,hidden,created_at,updated_at) VALUES(?,4,?,?,?, ?,?)').bind(member,title,'News body',hidden,'2026-10-27T12:00:00.000Z','2026-10-27T12:00:00.000Z').run().meta.last_row_id;
 const ids=Array.from({length:5},(_,i)=>add('News story '+(i+1)));
 add('Hidden announcement',1);
 let first=(await f.forum(null,null,{view:'news'})).data;
 assert.equal(first.articles.length,5);assert.equal(first.hasMore,false);assert.equal(first.page,1);
 ids.push(add('Sixth news story'));
 first=(await f.forum(null,null,{view:'news'})).data;
 const second=(await f.forum(null,null,{view:'news',page:2})).data;
 assert.equal(first.articles.length,5);assert.equal(first.hasMore,true);
 assert.equal(second.articles.length,1);assert.equal(second.hasMore,false);assert.equal(second.page,2);
 assert.deepEqual([...first.articles,...second.articles].map(t=>t.id),[...ids].reverse());
 for(let i=7;i<=11;i++)ids.push(add('News story '+i));
 const batches=await Promise.all([1,2,3].map(async page=>(await f.forum(null,null,{view:'news',page})).data));
 assert.deepEqual(batches.map(d=>d.articles.length),[5,5,1]);
 assert.deepEqual(batches.map(d=>d.hasMore),[true,true,false]);
 assert.deepEqual(batches.flatMap(d=>d.articles.map(t=>t.id)),[...ids].reverse());
 assert.equal((await f.forum(null,null,{view:'latestNews'})).data.article.id,ids.at(-1));
 assert.deepEqual((await f.forum(null,null,{view:'news',page:4})).data.articles,[]);
});

test('public deck links expose only opted-in decks and are revoked on privacy changes or deletion',async()=>{
 const f=await fixture();await f.register('alice');await f.register('bob');
 const call=async(who,data,share)=>{const r=await decksRequest(new Request('https://dragonball.test/api/decks'+(share?'?share='+encodeURIComponent(share):''),{method:data?'POST':'GET',headers:{Cookie:f.cookies[who]||'',Origin:'https://dragonball.test','Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})}),f.env);return {status:r.status,data:await r.json()};};
 const owner=(await call('alice')).data;
 const deck={id:'share-test',name:'Public test',visibility:'private',tokui:'',personalities:[null,null,null,null,null],cards:[],senseiDeck:[],mastery:null,sensei:null};
 let version=0;const save=async decks=>{const r=await call('alice',{userId:owner.userId,version,data:{decks,active:decks[0]?.id||null}});assert.equal(r.status,200);version=r.data.version;return r.data;};
 assert.deepEqual((await save([deck])).shares,{});
 assert.equal((await call(null,null,deck.id)).status,404);
 deck.visibility='public';const id=(await save([deck])).shares[deck.id];assert.ok(id);
 const publicResult=await call(null,null,id);assert.equal(publicResult.status,200);assert.equal(publicResult.data.deck.name,deck.name);assert.deepEqual(Object.keys(publicResult.data),['deck']);
 assert.equal((await call('bob',{userId:owner.userId,version,data:{decks:[],active:null}})).status,409);
 deck.name='Updated public deck';assert.equal((await save([deck])).shares[deck.id],id);assert.equal((await call(null,null,id)).data.deck.name,deck.name);
 deck.visibility='private';await save([deck]);assert.equal((await call(null,null,id)).status,404);
 deck.visibility='public';const newId=(await save([deck])).shares[deck.id];assert.notEqual(newId,id);
 await save([]);assert.equal((await call(null,null,newId)).status,404);
});

test('restore Kaoxt login and public name once without changing credentials or ownership',async()=>{
 const f=await fixture();await f.register('kurt');const user=(await f.auth('kurt','session')).data.user;
 f.env.DB.prepare('UPDATE forum_members SET id=? WHERE user_id=?').bind('7bb24f5c-1f13-4bfc-af60-c153f980e9af',user.id).run();
 const before=f.env.DB.prepare('SELECT * FROM auth_accounts WHERE id=?').bind(user.id).first();
 const post=(await f.forum('kurt',topic)).data.id;
 assert.equal(migrateKaoxtIdentity(f.env.DB),'renamed');
 assert.deepEqual({...f.env.DB.prepare('SELECT * FROM auth_accounts WHERE id=?').bind(user.id).first()},{...before,username:'Kaoxt'});
 const session=(await f.auth('kurt','session')).data.user;assert.equal(session.id,user.id);assert.equal(session.username,'Kaoxt');assert.equal(session.displayName,'Kaoxt');
 assert.equal((await f.forum(null,null,{view:'topic',id:post})).data.topic.author,'Kaoxt');
 assert.equal((await f.auth('new','login',{username:'Kaoxt',password:'My private password 123!'})).status,200);
 assert.equal(migrateKaoxtIdentity(f.env.DB),'completed');
});
test('Kaoxt restore never renames unrelated members or takes an occupied login',async()=>{
 const f=await fixture();await f.register('kurt');assert.equal(migrateKaoxtIdentity(f.env.DB),'not-applicable');
 const user=(await f.auth('kurt','session')).data.user;f.env.DB.prepare('UPDATE forum_members SET id=? WHERE user_id=?').bind('7bb24f5c-1f13-4bfc-af60-c153f980e9af',user.id).run();
 await f.register('kaoxt');assert.equal(migrateKaoxtIdentity(f.env.DB),'conflict');assert.equal((await f.auth('kurt','session')).data.user.username,'kurt');
});


test('requested Kaoxt admin grant is tied to the established identity and applies only once',async()=>{
 const f=await fixture();await f.register('kaoxt');await f.register('other');
 const user=(await f.auth('kaoxt','session')).data.user;
 f.env.DB.prepare('UPDATE forum_members SET id=? WHERE user_id=?').bind('7bb24f5c-1f13-4bfc-af60-c153f980e9af',user.id).run();
 assert.equal(grantKaoxtAdministrator(f.env.DB),'not-applicable');
 assert.equal(migrateKaoxtIdentity(f.env.DB),'renamed');
 const before=f.env.DB.prepare('SELECT * FROM auth_accounts WHERE id=?').bind(user.id).first();
 const sessions=f.env.DB.prepare('SELECT * FROM auth_sessions WHERE user_id=?').bind(user.id).all().results;
 f.env.DB.prepare("INSERT INTO auth_settings(key,value) VALUES('owner_claimed','existing-owner')").run();
 assert.equal(grantKaoxtAdministrator(f.env.DB),'granted');
 assert.deepEqual({...f.env.DB.prepare('SELECT * FROM auth_accounts WHERE id=?').bind(user.id).first()},{...before,role:'admin'});
 assert.deepEqual(f.env.DB.prepare('SELECT * FROM auth_sessions WHERE user_id=?').bind(user.id).all().results,sessions);
 assert.equal((await f.auth('kaoxt','session')).data.user.isAdmin,true);
 assert.equal((await f.auth('other','session')).data.user.isAdmin,false);
 assert.equal((await f.forum('kaoxt',null,{view:'admin'})).status,200);
 assert.equal(f.env.DB.prepare("SELECT value FROM auth_settings WHERE key='owner_claimed'").first().value,'existing-owner');
 f.env.DB.prepare("UPDATE auth_accounts SET role='member' WHERE id=?").bind(user.id).run();
 assert.equal(grantKaoxtAdministrator(f.env.DB),'completed');
 assert.equal((await f.auth('kaoxt','session')).data.user.isAdmin,false);
});

test('Kaoxt admin grant rejects a matching username without the established member identity',async()=>{
 const f=await fixture();await f.register('kaoxt');const user=(await f.auth('kaoxt','session')).data.user;
 f.env.DB.prepare('INSERT INTO auth_settings(key,value) VALUES(?,?)').bind('2026-10-10-restore-kaoxt-identity',user.id).run();
 assert.equal(grantKaoxtAdministrator(f.env.DB),'not-applicable');
 assert.equal((await f.auth('kaoxt','session')).data.user.isAdmin,false);
 f.env.DB.prepare('UPDATE forum_members SET id=? WHERE user_id=?').bind('7bb24f5c-1f13-4bfc-af60-c153f980e9af',user.id).run();
 f.env.DB.prepare("UPDATE auth_accounts SET username='different' WHERE id=?").bind(user.id).run();
 assert.equal(grantKaoxtAdministrator(f.env.DB),'not-applicable');
 assert.equal(f.env.DB.prepare('SELECT role FROM auth_accounts WHERE id=?').bind(user.id).first().role,'member');
});


async function imageFixture() {
 const f=await fixture(),objects=new Map();
 f.env.UPLOADS={async put(key,bytes){objects.set(key,Buffer.from(bytes));},async get(key){return objects.has(key)?{body:objects.get(key)}:null;}};
 const jpeg=Buffer.from([255,216,255,224,0,2,255,217]);
 f.upload=(who,bytes=jpeg,origin='https://dragonball.test',type='image/jpeg')=>forumImageRequest(new Request('https://dragonball.test/api/forum/images',{method:'POST',headers:{Origin:origin,Cookie:f.cookies[who]||'','Content-Type':type},body:bytes}),f.env);
 f.image=(url,who)=>forumImageRequest(new Request('https://dragonball.test'+url,{headers:{Cookie:f.cookies[who]||''}}),f.env);
 return f;
}
test('post image uploads require an active account, same origin, bounded JPEG bytes, and posting permission',async()=>{
 const f=await imageFixture();await f.register('alice');
 assert.equal((await f.upload(null)).status,401);
 assert.equal((await f.upload('alice',undefined,'https://evil.test')).status,403);
 assert.equal((await f.upload('alice',Buffer.from('<script>bad</script>'))).status,400);
 assert.equal((await f.upload('alice',undefined,undefined,'image/svg+xml')).status,415);
 assert.equal((await f.upload('alice',Buffer.alloc(FORUM_IMAGE_LIMIT+1))).status,413);
 f.env.DB.prepare('UPDATE forum_members SET banned=1').run();
 assert.equal((await f.upload('alice')).status,403);
 f.env.DB.prepare('UPDATE forum_members SET banned=0').run();
 f.env.DB.prepare('UPDATE forum_settings SET posting_open=0').run();
 assert.equal((await f.upload('alice')).status,409);
 assert.equal(f.env.DB.prepare('SELECT COUNT(*) AS n FROM forum_images').first().n,0);
});
test('image drafts are private and published images follow topic and reply visibility',async()=>{
 const f=await imageFixture();await f.register('alice');await f.register('bob');
 const uploaded=await f.upload('alice');assert.equal(uploaded.status,201);const {url}=await uploaded.json();
 assert.equal((await f.image(url)).status,404);assert.equal((await f.image(url,'bob')).status,404);
 const own=await f.image(url,'alice');assert.equal(own.status,200);assert.equal(own.headers.get('Content-Type'),'image/jpeg');assert.equal(own.headers.get('Cache-Control'),'private, no-store');
 const id=(await f.forum('alice',{...topic,body:'My deck\n![Deck]('+url+')'})).data.id;
 assert.equal((await f.image(url)).status,200);
 f.env.DB.prepare('UPDATE forum_topics SET hidden=1 WHERE id=?').bind(id).run();
 assert.equal((await f.image(url)).status,404);
 f.env.DB.prepare('UPDATE forum_topics SET hidden=0,body=? WHERE id=?').bind('Image removed',id).run();
 assert.equal((await f.image(url)).status,404);
 const reply=await f.forum('alice',{action:'reply',id,body:'![Deck]('+url+')'});assert.equal(reply.status,201);
 assert.equal((await f.image(url)).status,200);
 f.env.DB.prepare('UPDATE forum_replies SET hidden=1 WHERE topic_id=?').bind(id).run();
 assert.equal((await f.image(url)).status,404);
 f.env.DB.prepare('UPDATE forum_replies SET hidden=0 WHERE topic_id=?').bind(id).run();
 f.env.DB.prepare('UPDATE forum_topics SET hidden=1 WHERE id=?').bind(id).run();
 assert.equal((await f.image(url)).status,404);
});
test('failed object storage writes remove image records and repeated uploads are rate limited',async()=>{
 const f=await imageFixture();await f.register('alice');
 f.env.UPLOADS.put=async()=>{throw new Error('storage unavailable');};
 assert.equal((await f.upload('alice')).status,503);
 assert.equal(f.env.DB.prepare('SELECT COUNT(*) AS n FROM forum_images').first().n,0);
 const owner=f.env.DB.prepare('SELECT user_id FROM forum_members').first().user_id;
 f.env.DB.prepare("UPDATE forum_rate_limits SET count=20 WHERE user_id=? AND scope='image-upload'").bind(owner).run();
 assert.equal((await f.upload('alice')).status,429);
});

test('the approved news image serves the V3 asset only after normal visibility checks',async()=>{
 const f=await imageFixture();await f.register('alice');
 const imageId='58cafd4e-c156-48fc-a53d-96b3ce890d89',url='/api/forum/images/'+imageId;
 const owner=f.env.DB.prepare('SELECT user_id FROM forum_members').first().user_id;
 const original=Buffer.from([255,216,255,224,0,2,255,217]);
 await f.env.UPLOADS.put('forum-images/'+imageId,original);
 f.env.DB.prepare('INSERT INTO forum_images(id,user_id,size,created_at) VALUES(?,?,?,?)').bind(imageId,owner,original.length,new Date().toISOString()).run();
 let assetReads=0,available=true;
 f.env.ASSETS={async fetch(request){
  assetReads++;assert.equal(new URL(request.url).pathname,'/assets/news/build-your-next-deck-v3.webp');
  return available?new Response('approved-v3',{headers:{'Content-Length':'11'}}):new Response(null,{status:404});
 }};
 assert.equal((await f.image(url)).status,404);assert.equal(assetReads,0);
 const id=(await f.forum('alice',{...topic,body:'![Deck]('+url+')'})).data.id;
 const body=f.env.DB.prepare('SELECT body FROM forum_topics WHERE id=?').bind(id).first().body;
 const response=await f.image(url);
 assert.equal(response.status,200);assert.equal(await response.text(),'approved-v3');
 assert.equal(response.headers.get('Content-Type'),'image/webp');
 assert.equal(response.headers.get('Content-Length'),'11');
 assert.equal(response.headers.get('Cache-Control'),'private, no-store');
 assert.equal(f.env.DB.prepare('SELECT body FROM forum_topics WHERE id=?').bind(id).first().body,body);
 available=false;
 const fallback=await f.image(url);assert.equal(fallback.headers.get('Content-Type'),'image/jpeg');
 assert.deepEqual(Buffer.from(await fallback.arrayBuffer()),original);
 f.env.DB.prepare('UPDATE forum_topics SET hidden=1 WHERE id=?').bind(id).run();
 const before=assetReads;assert.equal((await f.image(url)).status,404);assert.equal(assetReads,before);
});

test('forum sections migrate existing forums without changing IDs or later assignments',async()=>{
 const backing=storage(),db=database(backing);
 authSchema(db);
 db.prepare("CREATE TABLE forum_categories (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL COLLATE NOCASE UNIQUE,description TEXT NOT NULL DEFAULT '',position INTEGER NOT NULL DEFAULT 0,archived INTEGER NOT NULL DEFAULT 0,read_only INTEGER NOT NULL DEFAULT 0)").run();
 db.prepare("INSERT INTO forum_categories(id,name,position,archived) VALUES(25,'Existing custom forum',37,1)").run();
 await forumDb({DB:db});
 assert.equal(db.prepare('SELECT section_id FROM forum_categories WHERE id=25').first().section_id,1);
 db.prepare("UPDATE forum_sections SET name='Community' WHERE id=1").run();
 db.prepare("INSERT INTO forum_sections(id,name,position) VALUES(2,'Card Games',-10)").run();
 db.prepare('UPDATE forum_categories SET section_id=2 WHERE id=25').run();
 await forumDb({DB:database(backing)});
 assert.deepEqual({...db.prepare('SELECT id,name,position,archived,section_id FROM forum_categories WHERE id=25').first()},{id:25,name:'Existing custom forum',position:37,archived:1,section_id:2});
 assert.equal(db.prepare('SELECT name FROM forum_sections WHERE id=1').first().name,'Community');
});

test('only admins can manage sections; forum moves keep topics and hierarchy intact',async()=>{
 const f=await fixture();await f.register('owner');await f.register('reader');
 await f.auth('owner','claim-owner',{code:'test-owner-code'});
 const section={action:'section',name:'Dragon Ball Z TCG',description:'Card game discussions',position:-5};
 assert.equal((await f.forum(null,section)).status,401);
 assert.equal((await f.forum('reader',section)).status,403);
 assert.equal((await f.forum('owner',section,{},'https://evil.test')).status,403);
 assert.equal((await f.forum('owner',section)).status,200);
 let admin=(await f.forum('owner',null,{view:'admin'})).data;
 const id=admin.sections.find(s=>s.name===section.name).id;
 assert.equal(admin.sections[0].id,id);
 assert.equal((await f.forum('owner',{...section,name:section.name.toLowerCase()})).status,400);
 assert.equal((await f.forum('owner',{...section,name:'',position:1})).status,400);
 assert.equal((await f.forum('owner',{...section,name:'Test',position:0.5})).status,400);
 assert.equal((await f.forum('owner',{...section,id:99999})).status,404);
 const topicId=(await f.forum('reader',topic)).data.id;
 const category={action:'category',id:1,name:'Gameplay',description:'Discuss gameplay',position:15,archived:false,readOnly:false,sectionId:id};
 assert.equal((await f.forum('reader',category)).status,403);
 assert.equal((await f.forum('owner',{...category,sectionId:99999})).status,400);
 assert.equal((await f.forum('owner',category)).status,200);
 let detail=(await f.forum(null,null,{view:'topic',id:topicId})).data;
 assert.equal(detail.topic.category_id,1);assert.equal(detail.topic.body,topic.body);
 assert.equal(detail.categories.find(c=>c.id===1).section_id,id);
 let grouped=(await f.forum(null,null,{view:'section',id})).data;
 assert.equal(grouped.section.name,section.name);assert.deepEqual(grouped.categories.map(c=>c.id),[1]);
 assert.equal(grouped.categories[0].topic_count,1);
 assert.equal((await f.forum(null,null,{view:'section',id:99999})).status,404);
 assert.equal((await f.forum(null,null,{view:'section',id:'invalid'})).status,404);
 assert.equal((await f.forum('owner',{...section,id,name:'Renamed section',position:10})).status,200);
 assert.equal((await f.forum(null,null,{view:'topic',id:topicId})).data.sections.find(s=>s.id===id).name,'Renamed section');
 // An older open admin tab must not silently move a forum back to the default group.
 const {sectionId,...legacyCategory}=category;
 assert.equal((await f.forum('owner',legacyCategory)).status,200);
 assert.equal((await f.forum(null,null,{view:'list',category:1})).data.categories.find(c=>c.id===1).section_id,id);
 assert.equal((await f.forum('owner',{...category,id:null,name:'New forum',position:30})).status,200);
 assert.equal((await f.forum('owner',{...category,id:2,name:'Decks',position:-20})).status,200);
 let ordered=(await f.forum(null,null,{view:'section',id})).data.categories;
 assert.deepEqual(ordered.map(c=>c.name),['Decks','Gameplay','New forum']);
 assert.equal((await f.forum('owner',{...category,position:-30})).status,200);
 ordered=(await f.forum(null,null,{view:'section',id})).data.categories;
 assert.deepEqual(ordered.map(c=>c.name),['Gameplay','Decks','New forum']);
 assert.deepEqual((await f.forum('owner',null,{view:'admin'})).data.sections.map(s=>s.id),[1,id]);
 assert.equal((await f.forum('owner',{...category,id:4,name:'Announcements',readOnly:false})).status,200);
 assert.equal((await f.forum('reader',{...topic,categoryId:4})).status,403);
 assert.equal((await f.forum('owner',{...category,archived:true})).status,200);
 assert.equal((await f.forum('reader',topic)).status,400);
 assert.equal((await f.forum(null,null,{view:'topic',id:topicId})).status,200);
});



test('account saves reject new Hi-Tech Allies while existing invalid decks remain repairable',async()=>{
 const {catalog}=await import('../public/cards/catalog.js');
 const {createDeck,snapshot}=await import('../public/decks/store.js');
 const f=await fixture();await f.register('alice');
 const call=async data=>{const r=await decksRequest(new Request('https://dragonball.test/api/decks',{method:data?'POST':'GET',headers:{Cookie:f.cookies.alice,Origin:'https://dragonball.test','Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})}),f.env);return {status:r.status,data:await r.json()};};
 const owner=(await call()).data;
 const ht=catalog.find(c=>c.rarity==='Hi-Tech'),deck=createDeck();
 let version=0;
 const save=async decks=>{const r=await call({userId:owner.userId,version,data:{decks,active:decks[0]?.id||null}});if(r.status===200)version=r.data.version;return r;};
 for(const zone of ['cards','senseiDeck']){
  deck[zone]=[{id:ht.id,name:ht.name,type:'Setup',qty:1}];
  const rejected=await save([deck]);assert.equal(rejected.status,400);assert.match(rejected.data.error,/Hi-Tech.*cannot be used as Allies/);
  deck[zone]=[];
 }
 deck.personalities[1]=snapshot(ht);assert.equal((await save([deck])).status,200);
 // Simulate a deck saved before this restriction, without silently deleting cards.
 deck.cards=[{id:ht.id,name:ht.name,qty:2}];
 f.env.DB.prepare('UPDATE account_decks SET data=? WHERE user_id=?').bind(JSON.stringify({decks:[deck],active:deck.id}),owner.userId).run();
 const other=createDeck();assert.equal((await save([deck,other])).status,200);
 deck.cards.push({id:ht.id,name:ht.name,qty:1});assert.equal((await save([deck,other])).status,400);deck.cards.pop();
 deck.cards[0].qty=1;assert.equal((await save([deck,other])).status,200);
 deck.cards[0].qty=2;assert.equal((await save([deck,other])).status,400);deck.cards[0].qty=1;
 const duplicate={...structuredClone(deck),id:'copied-invalid-deck'};assert.equal((await save([deck,other,duplicate])).status,400);
 deck.cards=[];assert.equal((await save([deck,other])).status,200);
 assert.equal((await call()).data.data.decks[0].cards.length,0);
});

test('GT Backer survives account and public saves; forged fields and invalid selections never persist',async()=>{
 const {gtFixture}=await import('./support/gt-backer-fixture.js');
 const {createBackerSystem}=await import('../public/cards/gt-backers.js');
 const f=await fixture(),gt=gtFixture(),backers=createBackerSystem(gt.catalog);await f.register('gtplayer');
 const call=async(body,share)=>{const response=await decksRequest(new Request('https://dragonball.test/api/decks'+(share?'?share='+share:''),{method:body?'POST':'GET',headers:{Cookie:share?'':f.cookies.gtplayer,Origin:'https://dragonball.test','Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})}),f.env,{backers});return {status:response.status,data:await response.json()};};
 const owner=(await call()).data;
 gt.deck.backer={id:gt.backer.id,name:'Forged name',image:'javascript:alert(1)',gtBacker:{pur:99}};
 const payload={userId:owner.userId,version:0,data:{decks:[gt.deck],active:gt.deck.id}};
 const saved=await call(payload);assert.equal(saved.status,200,JSON.stringify(saved));
 const stored=(await call()).data.data.decks[0];assert.equal(stored.backer.name,gt.backer.name);assert.equal(stored.backer.image,gt.backer.image);assert.equal(stored.backer.gtBacker,undefined);
 const shared=await call(null,saved.data.shares[gt.deck.id]);assert.deepEqual(shared.data.deck.backer,stored.backer);
 payload.version=1;gt.deck.backer.id='unknown';assert.equal((await call(payload)).status,400);assert.equal((await call()).data.version,1);
 gt.deck.backer=null;assert.equal((await call(payload)).status,200); // Incomplete drafts remain editable.
});
