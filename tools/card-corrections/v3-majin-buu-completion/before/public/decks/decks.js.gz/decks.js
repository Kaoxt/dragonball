import {gtBackers} from '../cards/gt-backers.js';
import {cardTypeLabel} from '../cards/card-types.js';
import {deckAdditionError, hiTechAllies, assertDeckEligible} from './eligibility.js';
import {setupDeckImages} from './deck-image.js';
import {catalog} from '../cards/catalog.js';
import {parseDeck} from '../game.js';
import {STORAGE_KEY, createDeck, readDecks, snapshot, count, exportDeck, addCard, selectBacker, removalTarget, deckSize, deckLimit} from './store.js';
const catalogById = new Map(catalog.map(card => [card.id, card]));
const $ = id => document.getElementById(id);
const node = (tag, text, className) => { const el=document.createElement(tag); if(text!==undefined)el.textContent=text;if(className)el.className=className;return el; };
const button = (text, label, action, className='') => {const b=node('button',text,className);b.type='button';b.setAttribute('aria-label',label);b.onclick=action;return b;};
const normalize = s => String(s || '').toLowerCase().replace(/[’']/g,'');
const gate=$('deck-access'),workspace=$('deck-workspace');
function showAccess(message,login=false){
 workspace.hidden=true;workspace.inert=true;gate.hidden=false;
 gate.replaceChildren(node('h1',login?'Log in to create decks':'Deck builder'),node('p',message));
 if(login){
  for(const [label,mode] of [['Log in','login'],['Create account','register']]){const link=node('a',label);link.href='/account/?mode='+mode+'&next='+encodeURIComponent(location.pathname+location.search);gate.append(link,node('span',' '));}
 }else gate.append(button('Try again','Reload deck builder',()=>location.reload()));
}
async function initialize(){
let data, storageBroken=false, visible=48, previewCard, messageTimer;
try { data=readDecks(); } catch {data={decks:[],active:null};storageBroken=true;}
const browserData=structuredClone(data);
let shares={};
let syncUser=null,syncVersion=0,syncBusy=false,syncDirty=false,syncBlocked=false,syncTimer;
function lockBuilder(){syncBlocked=true;syncDirty=false;clearTimeout(syncTimer);for(const dialog of document.querySelectorAll('dialog[open]'))dialog.close();showAccess('Log in or create an account to build and save your decks.',true);}
window.addEventListener('dragon:auth-signed-out',lockBuilder);
const response=await (window.DragonNetwork?.fetch || fetch)('/api/decks',{credentials:'same-origin',cache:'no-store'});
if(response.status===401){lockBuilder();return;}
if(syncBlocked)return;
const result=await response.json();
if(!response.ok)throw Error(result.error||'Unable to load account decks.');
if(!result.userId)throw Error('Unable to verify your account.');
shares=result.shares||{};syncUser=result.userId;syncVersion=result.version;data=result.data;storageBroken=false;
if(!data.decks.length){const fresh=createDeck();data.decks.push(fresh);data.active=fresh.id;}
const requestedDeck=new URLSearchParams(location.search).get('deck');
let deck=data.decks.find(d=>d.id===(requestedDeck||data.active))||data.decks[0];
function message(text){$('builder-message').textContent=text;clearTimeout(messageTimer);messageTimer=setTimeout(()=>$('builder-message').textContent='',4500);}
async function syncDecks(){
 if(!syncUser||syncBusy||syncBlocked||!syncDirty)return;
 syncBusy=true;syncDirty=false;$('save-status').textContent='Saving to account…';
 try{const response=await (window.DragonNetwork?.fetch || fetch)('/api/decks',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({userId:syncUser,version:syncVersion,data})});const result=await response.json();if(response.status===401){lockBuilder();return;}if(!response.ok){if([400,401,409,413].includes(response.status))syncBlocked=true;throw Error(result.error||'Unable to sync decks.');}syncVersion=result.version;shares=result.shares||{};renderSharing();$('save-status').textContent='Saved to your account';}
 catch(e){syncDirty=true;$('save-status').textContent=e.message+' Your edits remain here; export a backup.';}
 finally{syncBusy=false;renderSharing();if(syncDirty&&!syncBlocked)syncTimer=setTimeout(syncDecks,5000);}
}
function save(){
 if(!syncUser||workspace.inert)return;
 data.active=deck.id;syncDirty=true;
 $('save-status').textContent=syncBlocked?'Sync paused — export changes and reload':'Saving to account…';
 clearTimeout(syncTimer);syncTimer=setTimeout(syncDecks,400);
}
function library(){ $('saved-decks').replaceChildren(...data.decks.map(d=>new Option(d.name||'Untitled deck',d.id)));$('saved-decks').value=deck.id; }
function changed(){
 if(deck.backer){try{gtBackers.validateDeck(deck);}catch{deck.backer=null;message('The Backer was cleared because it no longer matches this Main Personality or style.');}}
 if(!gtBackers.needsBacker(deck)&&deck.personalities.length===6&&!deck.personalities[5])deck.personalities.length=5;
 save();renderDeck();renderCounts();
}
function add(c){try{addCard(deck,c,$('destination').value);changed();message(`Added ${c.name}`);$('preview-status').textContent=`Added ${c.name}`;}catch(e){message(e.message);$('preview-status').textContent=e.message;}}
function openPreview(c){previewCard=c;let shown=c;try{if(deck.personalities.some(p=>p?.id===c.id))shown=gtBackers.preview(c,deck);}catch(e){message(e.message);}$('preview-image').src=shown.image;$('preview-image').alt=c.name;$('preview-name').textContent=c.name;$('preview-meta').textContent=[c.set,c.number&&`#${c.number}`].filter(Boolean).join(' · ');$('preview-type').textContent=[cardTypeLabel(c.type),c.style,c.level&&`Level ${c.level}`].filter(Boolean).join(' · ');$('preview-rules').textContent=shown.rules||'';$('download-composite').hidden=!shown.backerId;$('download-composite').href=shown.backerId?shown.downloadImage:'#';$('download-composite').download=c.id+'-with-backer.svg';updatePreviewEligibility();$('card-preview').showModal();}
function updatePreviewEligibility(){
 const error=deckAdditionError(previewCard,$('destination').value);
 $('preview-add').disabled=Boolean(error);
 $('preview-status').textContent=error;
}
function totalFor(id){return [...deck.cards,...deck.senseiDeck,...deck.personalities.filter(Boolean),deck.mastery,deck.sensei].filter(c=>c?.id===id).reduce((n,c)=>n+(c.qty||1),0);}
function removeFromBrowser(c){const target=removalTarget(deck,c,$('destination').value);if(!target)return;remove(target.zone,target.card,target.index);message(`Removed one ${c.name}`);}
function renderCounts(){
 const destination=$('destination').value;
 document.querySelectorAll('.remove-card').forEach(b=>{b.disabled=!removalTarget(deck,{id:b.dataset.id},destination);});
 document.querySelectorAll('.add-card').forEach(button=>{
  const card=catalogById.get(button.dataset.id);
  const error=deckAdditionError(card,destination);
  const copies=totalFor(card.id);
  button.disabled=Boolean(error);
  button.title=error;
  button.textContent=card.banned?'Banned':error?'Starting stack only':copies?`+ Add · ${copies} in deck`:'+ Add';
 });
}
function browse(){
 const q=normalize($('query').value.trim());
 const cards=catalog.filter(c=>normalize(`${c.name} ${c.number} ${c.rules||''}`).includes(q)&&['set','style','type'].every(k=>!$(k).value||$(k).value===c[k])).sort((a,b)=>a.name.localeCompare(b.name)||String(a.number).localeCompare(String(b.number),undefined,{numeric:true}));
 $('results').textContent=`${cards.length} card${cards.length===1?'':'s'}`;$('empty-results').hidden=cards.length>0;$('more-cards').hidden=cards.length<=visible;
 $('card-grid').replaceChildren(...cards.slice(0,visible).map(c=>{
  const article=node('article',undefined,'browse-card'),art=button('',`Preview ${c.name}, ${c.set} #${c.number}`,()=>openPreview(c),'card-art');
  const img=node('img');img.src=c.image;img.alt=c.name;img.loading='lazy';img.width=1070;img.height=1470;art.append(img);
  const addButton=button('+ Add',`Add ${c.name}, ${c.set} #${c.number}`,()=>add(c),'add-card');addButton.dataset.id=c.id;
  const removeButton=button('− Remove',`Remove one ${c.name}, ${c.set} #${c.number}`,()=>removeFromBrowser(c),'remove-card');removeButton.dataset.id=c.id;
  const actions=node('div',undefined,'browse-card-actions');actions.append(removeButton,addButton);
  article.append(art,node('h2',c.name),node('p',`#${c.number} · ${cardTypeLabel(c.type)}${c.level?' · L'+c.level:''}`),actions);return article;
 }));renderCounts();
}
function remove(zone,c,index){if(zone==='personalities')deck.personalities[index]=null;else if(['mastery','sensei'].includes(zone))deck[zone]=null;else{c.qty--;if(c.qty<=0)deck[zone]=deck[zone].filter(x=>x.id!==c.id);}changed();}
function row(c,zone,index){
 const el=node('div',undefined,'deck-row');const title=button(c.name,`Preview ${c.name}`,()=>openPreview(catalog.find(x=>x.id===c.id)||c),'row-name');
 if(c.number)title.append(node('span',`#${c.number}${c.set?' · '+c.set:''}`,'row-meta'));el.append(title);
 const controls=node('div',undefined,'quantity');
 if(zone==='cards'||zone==='senseiDeck'){
 controls.append(button('−',`Remove one ${c.name}`,()=>remove(zone,c,index),'small-control'),node('span',c.qty),button('+',`Add one ${c.name}`,()=>{try{addCard(deck,c,zone);changed();}catch(e){message(e.message);}},'small-control'));
 }else controls.append(button('×',`Remove ${c.name}`,()=>remove(zone,c,index),'small-control'));
 el.append(controls);return el;
}
function renderSharing(){
 $('deck-visibility').value=deck.visibility||'private';$('deck-visibility').disabled=!syncUser;
 $('share-deck').hidden=!syncUser||deck.visibility!=='public';$('share-deck').disabled=syncDirty||syncBusy||!shares[deck.id];
}
function renderBacker(){
 const panel=$('gt-backer-panel');panel.hidden=!gtBackers.needsBacker(deck);
 if(panel.hidden)return;
 const options=gtBackers.choices(deck),select=$('gt-backer');
 select.replaceChildren(new Option('Choose a Backer',''),...options.map(c=>new Option(c.name+' · '+c.set+' #'+c.number,c.id)));
 select.value=deck.backer?.id||'';
 $('gt-backer-note').textContent=deck.backer?'Applies to every GT Hi-Tech level. Excluded from deck size.':options.length?'Choose one Backer for all GT Hi-Tech levels before playing.':'No Backers match this Main Personality and Tokui-Waza.';
}
function renderDeck(){
 renderBacker();
 renderSharing();
 $('deck-name').value=deck.name;$('tokui').value=deck.tokui;
 $('life-count').textContent=$('life-label').textContent=count(deck.cards);$('sensei-count').textContent=$('sensei-label').textContent=count(deck.senseiDeck);$('starting-count').textContent=deck.personalities.filter(Boolean).length+!!deck.mastery+!!deck.sensei;$('tab-count').textContent=count(deck.cards);
 $('personalities').replaceChildren(...deck.personalities.map((c,i)=>{const slot=node('div',undefined,'mp-slot');slot.append(node('span',i+1,'level-number'));slot.append(c?row(c,'personalities',i):node('span','Choose a personality','empty-slot'));return slot;}));
 $('starting-extras').replaceChildren(...['mastery','sensei'].map(k=>{const el=node('div',undefined,'extra-row');el.append(node('span',k==='mastery'?'Mastery':'Sensei','extra-label'),deck[k]?row(deck[k],k):node('span','Not selected','empty-slot'));return el;}));
 for(const [key,id,empty]of[['cards','life-list','Add cards from the collection to start your Life Deck.'],['senseiDeck','sensei-list','Choose “Sensei Deck” above the collection to add cards here.']]){
 const cards=[...deck[key]].sort((a,b)=>a.name.localeCompare(b.name));$(id).replaceChildren(...(cards.length?cards.map(c=>row(c,key)):[node('p',empty,'list-empty')]));
 }
 const checks=hiTechAllies(deck).map(({card,zone})=>`${card.name}: remove this Hi-Tech Personality from the ${zone==='cards'?'Life Deck':'Sensei Deck'}; it cannot be an Ally.`);
 try{gtBackers.validateDeck(deck,{required:true});}catch(e){checks.push(e.message);}
 const stack=deck.personalities.filter(Boolean);
 if(new Set(stack.map(c=>c.id)).size!==stack.length)checks.push('Remove duplicate Main Personality cards: use each card only once.');
 if(new Set(stack.map(c=>c.name.trim().toLowerCase())).size>1)checks.push('All Main Personality levels must belong to the same character.');
if(deckSize(deck)<50||deckSize(deck)>deckLimit(deck))checks.push(`Deck size: ${deckSize(deck)} of 50–${deckLimit(deck)} cards, including starting cards.`);const last=deck.personalities.findLastIndex(Boolean);
 if(last<2||deck.personalities.slice(0,last+1).some(c=>!c))checks.push('Choose consecutive Main Personality levels starting at level 1 (at least three).');
 if(deck.personalities.some((c,i)=>c?.level&&c.level!==i+1))checks.push('One or more personalities are in the wrong level slot.');
 if(!checks.length){try{checks.push(...parseDeck(exportDeck(deck)).warnings);}catch(e){checks.push(e.message);}}
 else{if(!deck.cards.length)checks.push('Add cards to your Life Deck.');if(deck.senseiDeck.length&&!deck.sensei)checks.push('Choose a Sensei for your Sensei Deck.');}
 $('checks-summary').textContent=`Deck checks${checks.length?' · '+checks.length+' to review':''}`;
 $('checks').replaceChildren(...(checks.length?checks:['Basic tabletop checks passed. Review card-specific restrictions.']).map(t=>node('li',t)));
}
for(const key of ['set','style','type']){for(const value of [...new Set(catalog.map(c=>c[key]).filter(Boolean))].sort())$(key).add(new Option(key==='type'?cardTypeLabel(value):value,value));$(key).onchange=()=>{visible=48;browse();};}
$('gt-backer').onchange=()=>{try{selectBacker(deck,$('gt-backer').value?{id:$('gt-backer').value}:null);changed();}catch(e){message(e.message);renderBacker();}};
$('destination').onchange=()=>{renderCounts();if(previewCard)updatePreviewEligibility();};
$('filters').onsubmit=e=>e.preventDefault();$('query').oninput=()=>{visible=48;browse();};$('reset-filters').onclick=()=>{$('filters').reset();visible=48;browse();};$('more-cards').onclick=()=>{visible+=48;browse();};
$('deck-name').oninput=()=>{deck.name=$('deck-name').value.slice(0,70);save();library();};$('deck-name').onblur=()=>{if(!deck.name.trim()){deck.name='Untitled deck';save();library();renderDeck();}};
$('deck-visibility').onchange=()=>{deck.visibility=$('deck-visibility').value;changed();};
$('share-deck').onclick=async()=>{if(!shares[deck.id])return;const url=location.origin+'/decks/shared.html?id='+encodeURIComponent(shares[deck.id]);try{await navigator.clipboard.writeText(url);message('Share link copied');}catch{window.prompt('Copy your public deck link',url);}};
$('tokui').onchange=()=>{deck.tokui=$('tokui').value;changed();};$('saved-decks').onchange=()=>{deck=data.decks.find(d=>d.id===$('saved-decks').value);changed();};
$('new-deck').onclick=()=>{deck=createDeck();data.decks.push(deck);changed();library();message('New deck created');};
$('duplicate-deck').onclick=()=>{try{assertDeckEligible(deck);}catch(e){message(e.message);return;}deck=structuredClone(deck);deck.id=crypto.randomUUID();deck.visibility='private';deck.name=(deck.name+' copy').slice(0,70);data.decks.push(deck);changed();library();message('Deck duplicated');};
$('delete-deck').onclick=()=>{$('delete-name').textContent=`“${deck.name||'Untitled deck'}” will be removed from ${syncUser?'your account':'this browser'}.`;$('delete-dialog').showModal();};$('cancel-delete').onclick=()=>$('delete-dialog').close();
$('confirm-delete').onclick=()=>{data.decks=data.decks.filter(d=>d.id!==deck.id);deck=data.decks[0]||createDeck();if(!data.decks.length)data.decks.push(deck);changed();library();$('delete-dialog').close();message('Deck deleted');};
$('close-preview').onclick=()=>$('card-preview').close();$('preview-add').onclick=()=>add(previewCard);
for(const view of ['cards','deck'])$(view+'-tab').onclick=()=>{document.querySelector('.builder-layout').dataset.view=view;for(const v of ['cards','deck'])$(v+'-tab').setAttribute('aria-pressed',String(v===view));};
window.addEventListener('storage',e=>{if(!syncUser&&e.key===STORAGE_KEY){storageBroken=true;$('save-status').textContent='Decks changed in another tab — reload before editing';message('Reload to use the latest saved decks.');}});
const syncNote=document.querySelector('.storage-note');
syncNote.textContent='Autosaved to your account across devices. Export a deck image to download a backup.';
if(syncUser&&browserData.decks.some(d=>d.cards.length||d.personalities.some(Boolean)||d.mastery||d.sensei)){
 const importButton=button('Import browser decks','Import decks saved in this browser',()=>{try{for(const d of browserData.decks.filter(d=>!data.decks.some(x=>x.id===d.id)))assertDeckEligible(d);}catch(e){message(e.message);return;}let added=0;for(const d of browserData.decks){if(!data.decks.some(x=>x.id===d.id)){data.decks.push({...structuredClone(d),visibility:'private'});added++;}}if(added){deck=data.decks.at(-1);changed();library();}message(added?`Imported ${added} browser decks`:'These browser decks are already in your account.');});
 syncNote.after(importButton);
}
window.addEventListener('beforeunload',event=>{if(syncUser&&(syncDirty||syncBusy)){event.preventDefault();event.returnValue='';}});
workspace.hidden=false;workspace.inert=false;gate.hidden=true;
library();browse();renderDeck();save();


setupDeckImages({catalog,getDeck:()=>deck,onImport:imported=>{if(syncBlocked)throw Error('Account sync is paused. Export your changes and reload before importing.');if(data.decks.length>=100)throw Error('You have reached 100 decks. Remove a deck before importing another.');assertDeckEligible(imported);data.decks.push(imported);deck=imported;changed();library();$('deck-tab').click();message('Imported as a new private deck');}});

}
await initialize().catch(()=>showAccess('Unable to load your account decks. Please try again.'));
