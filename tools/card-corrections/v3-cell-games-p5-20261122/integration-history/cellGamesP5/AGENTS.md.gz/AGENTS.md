## Cell previews and Cell Games promos/previews — November 21, 2026

Preserve the 22 exact supplied native SVGs and 44 lossless exports in
`cell-completion-20261121`: Cell PR1–PR6; Cell Games P1–P4, P6–P10 and PR1–PR7.
Cell Games P5 Goku Charges is pending artwork and is deliberately not playable
yet. Keep printed rarity stars, CRD restrictions and append-only deck IDs.
Evidence is in `tools/card-corrections/v3-cell-completion-20261121/`.
Earlier immutable audits start with `pre-cell-completion.js` before the
remaining-personality history. Do not regenerate supplied exports or alter
existing card records during publication. No deployment is claimed.

## Remaining Personality corrections — November 15, 2026

Preserve the supplied 56 artwork placement corrections, Saiyan Vegeta #184's
"Stops an energy attack." wording, and Saiyan Goku #160's Arena stages
8,000 / 8,500. The 58 affected records include 57 image cards and 114 exact
lossless exports. Retain native sources, linked artwork, fixed UI and prior
repair layers. Four recorded proportional framing exceptions retain their
original artwork; do not regenerate or globally rerender the supplied WebPs.
Cell #159's subject mask and artwork pin move together; the Hi-Tech title mask
remains unchanged. Evidence and independent protected-pixel verification are
in `tools/card-corrections/remaining-personality-fixes-20261115/`.
Historical audits start with `remaining-personality-history.js` before the
previous centering history. Preserve earlier audit manifests unchanged.

## Personality artwork centering — November 15, 2026

Preserve the supplied horizontal artwork correction on 45 personalities: 17
Frieza, 22 Trunks, three Android and World Games Pikkon #161/#190/#191.
The other 53 reviewed cards retain their optical placement. Both lossless
exports preserve every pixel outside x14–814, y146–852. Keep the original
native elements, repair layers, scale, vertical position and all gameplay data.
Canonical SVGs and their web-1x companions retain their linked art assets.
Frieza #125 and Trunks #156 masks move with their exact pinned artwork revisions.
Piccolo #169's narrow background/cape edge exception is recorded in REVIEW-NOTES.
Evidence is in `tools/card-corrections/personality-centering-20261115/`.
Earlier audits start with `personality-centering-history.js`; use its hash API
for historical raster identity and its file API for exact native snapshots.
Do not rerender or recompress the supplied WebPs during publication.

## Cell Saga promos P1–P10 — November 15, 2026

Preserve the ten supplied native SVGs, linked artwork and twenty lossless
exports in `cell-promos-p1-p10`, including the approved direct P3 restoration
and its lower-edge continuation. These ten playable promos extend Cell Saga
1–200 to 210 cards; numbered cards, Hi-Tech cards and Goku #162 are unchanged.
Keep the CRD wording, two-star rarity and append-only permanent deck IDs.
Historical audits start with `pre-cell-promos.js` before the World Games
promo history. Evidence is in `tools/card-corrections/v3-cell-promos-p1-p10/`.

## World Games Videl 201, promos and previews — November 15, 2026

Preserve the 18 exact supplied native sources and 36 lossless exports in
`world-games-201-promos`, including landscape P1 and Hi-Tech Videl 201.
P1–P10 and PR1–PR7 are distinct World Games numbers; retain sourceNumber and
subset provenance. Supreme Kai PR6 has zero followed by eleven string Z stages
in Arena. Videl uses the existing corrected Hi-Tech title mask. Historical
audits start with `pre-world-games-promos.js` before the Cell starter history.
Publication evidence is in `tools/card-corrections/v3-world-games-201-promos/`.

## Cell Saga 161–190 completion — November 15, 2026

The thirty supplied regular Starter Personalities complete Cell Saga 1–200.
Preserve all exact native sources in `tools/card-templates/v3/cell-161-200/`,
linked artwork, sixty lossless exports and printed Level/PUR/stages. Goku #162
retains the user-selected illustration and uniform 35% enlargement. Android 17
#180 uses AT +6 stages when The Car is in play. Cell Hi-Tech #191–200 remain
unchanged. Evidence is in `tools/card-corrections/v3-cell-starters-161-190/`.
The permanent deck IDs preserve the supplied order with Goku #162 appended
last. Earlier audits use `pre-cell-starters-catalog.js` before Cell Games history.

## Cell Games Saga 101–125 — November 14, 2026

The 25 supplied V3 cards complete the numbered Cell Games set through 125.
Preserve their exact native SVGs, content-addressed assets and 50 lossless
exports. #117 is landscape; #124/#125 use the existing Ultra Rare V3 fallback
finish. Five explicit Arena charts support deck snapshots, with printed stages
highest to zero. Source scans, CRD review and publication evidence are retained
in `tools/card-corrections/v3-cell-games-101-125/`. Earlier audits use the
`pre-cell-games-101-125.js` helper before the Goku background revision.

## Goku #173 matching Hi-Tech eye background — November 14, 2026

The user's later correction updates only Goku's background silhouette to the
same oversized cropped-eye treatment as the other World Games Hi-Tech cards.
Preserve the original foreground PNG, its placement, and all original native
elements. The localized generated background layer uses the retained art-window
clip and gradient masks; changes are confined to x350–1060, y146–852 at both
export sizes. Evidence is in `tools/card-corrections/v3-world-games-173-eye-background/`.
Follow `goku-eye-background-history.js` before the older framing history helper.
This supersedes the earlier instruction to retain Goku's background unchanged;
his halo-and-staff foreground choice remains unchanged.

## World Games Hi-Tech framing — November 14, 2026

Eight Hi-Tech cards (#165, #169, #177, #181, #185, #189, #193, #197) retain the
exact supplied self-contained native sources and lossless exports from
`World-Games-Hi-Tech-Refined-Cards.zip`. Preserve the individually fitted
foregrounds, painted eye backgrounds and Pikkon's localized open mouth. All
protected native groups and gameplay fields are unchanged. Goku #173 retains
the previously published `cc3291d` choice, as required by the package handoff.
Current metadata is in the 151–200 batch; revision evidence and exact earlier
snapshots are in `tools/card-corrections/v3-world-games-hi-tech-refined/`.
Use the retained-native rebuild path and the explicit historical revision helper.

## Cell Saga Hi-Tech 191–200 — November 14, 2026

The ten user-supplied Level 3 Hi-Tech cards are retained in
`tools/card-templates/v3/cell-191-200/`, with publication evidence in
`tools/card-corrections/v3-cell-191-200/`. Preserve the exact approved native
sources, linked artwork and both lossless exports, including Goku's selected
palette and Gohan's face correction. The package's draft labels and old source
paths are historical; use the normalized audit paths. These are Cell Saga
cards, independent of World Games #173. The new deck IDs are appended, Arena
charts preserve every printed stage, and earlier audits retain their original
membership. Cell #161–190 are not part of this release.

## World Games Earth Dragon Ball artwork — November 11, 2026

Use the user-approved downward right-facing Shenron with an upper-left arched
neck and slightly open mouth for every World Games Earth Dragon Ball. The
set-specific source and native mapping are recorded in
`tools/card-corrections/v3-world-games-shenron/release.json` and
`tools/card-templates/v3/references/world-games-dragon-ball.md`.
Both World Games builders use `scripts/world_games_dragon_ball.py` before
assetizing the illustration. Preserve the full 1060×1484 mapping, existing
single brightness gain, native UI, rules and numbered left orb. Other sets
retain their artwork. The current 001–150 catalog contains only #15 Earth
Dragon Ball 3; later World Games Dragon Balls inherit this default.
Earlier audits stay immutable and use the reversible Shenron history helper.

## World Games Saga 051–100 complete handoff — November 11, 2026

All 50 additional cards are prepared in current V3 with the November 10 symbol
weights. Cards 053 Blue Quick Blast and 066 Namekian Combo now use the user-supplied
replacement artwork, completing the prepared World Games catalog through 100.
No deployment is claimed. Evidence is in
`tools/card-corrections/v3-world-games-051-100/`.

Preserve all 50 native sources and 100 lossless display/download exports. The
previously delivered 48 sources and 96 exports are byte-identical. Retain the
approved #53 illustration and #66 cleanup, with source limitations documented
per card. #91 is landscape; #99 Krillin is Level 1/PUR 2 with stages highest to 0.
Blue, Namekian, Orange and Freestyle use the thinner approved weights; Red retains
its reference weight. Historical symbol audits keep their original membership
through `tests/helpers/pre-world-games-051-100-catalog.js`. New batch tests cover
symbols, sources, images, routes and deck codes independently.

## Orange Tokui Waza stroke weight — November 10, 2026

The current Orange correction includes all 82 catalog cards across seven sets,
both enlarged Masteries and the four World Games Orange cards. Keep the 橙 paths,
#f29216 orange, round caps/joins, dark outline, transforms, placement, total
symbol footprint and smoky backing. Only the colored stroke changes from
7.6923 to 6.92307 (10% reduction), about 10.906 to 9.815 native pixels at the
standard placement. Reuse corrected Saiyan #49, selected by the current
builders, or scripts/orange_symbol_weight.py after choosing a retained older
Orange source. Do not reduce the size or compound the thinning.
Both lossless exports preserve every pixel outside the symbol delta.
Cell Games #70/#72/#73 still lack complete native SVGs from their old release;
their verified fully opaque shared-logo delta is patched without reconstructing
or claiming recovery of their full cards. Preserve this provenance distinction.
Use tools/card-corrections/v3-orange-stroke-weight/ and both Node/Python revision
chains; retain historical audits. Keep the Orange → Blue → Black → Freestyle
revision order so each earlier audit sees its original reviewed state.

## Blue Tokui Waza stroke weight — November 10, 2026

The Blue correction covers all 81 catalog cards across seven sets,
including both enlarged Masteries and all nine World Games Blue cards.
Retain the 青 paths, blue #3b9cde, rounded caps/joins, width-13 dark outline,
transforms, position, total outer footprint and smoky backing. Only the blue
paint stroke changes from 7.69230769 to 7.403846151625 (3.75% reduction),
about 10.1762 to 9.7946 native pixels at standard placement, matching the
approximate 9.8-pixel Red reference. Use the corrected Saiyan #13 donor or
scripts/blue_symbol_weight.py after selecting a Blue symbol for a new card.
Existing corrections use byte-preserving native edits and independently
rendered per-card before/after crops. Keep all unrelated pixels unchanged in
both lossless exports. Preserve earlier audit evidence through the reversible
revision chain in tools/card-corrections/v3-blue-stroke-weight/. Both the Node
and Python audit readers retain the published Black revision in that chain.

## Black Tokui Waza stroke weight — November 10, 2026

All 90 current Black cards retain the same 黒 paths, gray #777d85, rounded
caps, dark width-13 outline, transforms, backing and total symbol footprint.
Only the gray stroke is reduced 10%, from 7.69230769 to 6.923076921 (about
10.90 to 9.81 native pixels at standard placement). Preserve both enlarged
Mastery placements. All 15 World Games Black cards are included. Reuse the
corrected Saiyan #65 donor or apply scripts/black_symbol_weight.py after style
selection. The two older Black symbol builders also apply this helper.
Evidence and reversible edits: tools/card-corrections/v3-black-stroke-weight/.
Keep every non-symbol pixel unchanged in both lossless export sizes; retain
historical audits and follow the explicit revision chain in both the Node
helpers and the Python card-type reference checks.

## Freestyle Tokui Waza stroke weight — November 10, 2026

All 374 published white 白 symbols retain their native paths, transforms,
placement, outer black silhouette and smoky backing. Only `freestyle-glyph`
adds `stroke="#080b0d" stroke-width="0.8" stroke-linejoin="round"`, insetting
white edges by 0.4 glyph units. Typical white weight is now about 9.78 native
pixels, matching Red's approximate 9.8. Use corrected Saiyan #24 as the donor,
or apply `tools/card-templates/v3/scripts/freestyle_symbol_weight.py` after
style selection. Do not restore the heavier historical donor. Personalities,
Dragon Balls and landscape cards do not use this symbol and stay unchanged.
Evidence and reversible edits are in `tools/card-corrections/v3-freestyle-stroke-weight/`.
Retain earlier audits unchanged and follow the revision chain. Preserve all
non-symbol pixels in both lossless exports and keep Ultra Rare custom masks
pinned to the current image revision after verified symbol-only changes.

## Namekian Tokui Waza stroke weight — November 10, 2026

All 65 current Namekian cards retain the same 瑪 paths, teal #21aaa5, rounded
caps, outline, transforms, backing and total symbol size. Only the teal stroke
is reduced 5%, from 7.69230769 to 7.3076923055 (about 10.32 to 9.80 native
pixels at the standard placement). Keep both enlarged Masteries unchanged in
scale. The six World Games Namekian cards are included. Use the corrected
Trunks #7 donor or scripts/namekian_symbol_weight.py after style selection.
The Namekian symbol builder now uses the thinner stroke too. Preserve all other
card pixels and historical audits; follow the reversible revision in
tools/card-corrections/v3-namekian-stroke-weight/. The older width documented
below is historical and must not be restored.

## Saiyan Tokui Waza stroke weight — November 10, 2026

All 70 current Saiyan-style cards use the same retained 緑 paths with only the
green `#30b477` stroke reduced by 12.5%, from `7.69230769` to `6.73076922875`.
This matches Red's approximate typical weight at the standard card placement.
Preserve the dark width-13 outline, transforms, total size, backing and all
other pixels. The two Mastery placements keep their existing enlargement.
Use the corrected current Saiyan #18 donor, or apply
`tools/card-templates/v3/scripts/saiyan_symbol_weight.py` after style selection.
Do not restore the old Saiyan colored width from the historical shared-style
instructions below. Other styles remain unchanged. Evidence and reversible
native edits are in `tools/card-corrections/v3-saiyan-stroke-weight/`; retain
earlier audits unchanged and follow the explicit revision chain.

## World Games Saga #34 completion — November 9, 2026

Saiyan Readied Attack now completes cards 001–050 using the user-approved 2060.png artwork and the reviewed display/download exports. See `tools/card-corrections/v3-world-games-034/`. Preserve the earlier 49-card release and archive audits as immutable history; their missing-034 entry is superseded by this separate completion record. The compact deck ID is appended without reordering existing IDs.

## World Games Saga 001–050 publication — November 9, 2026

49 completed cards are published from the retained progress archive, with native sources in `tools/card-templates/v3/world-games-001-050/` and evidence in `tools/card-corrections/v3-world-games-001-050/`. Card 034 (Saiyan Readied Attack) remains unpublished because only its original reference scan is available. Preserve all 98 completed export bytes, native sources, prior audits and the explicit gap. Card 038 is landscape. See `release.json` and `README.md`; differing archive-only shared dependencies are retained separately and must not overwrite existing templates.

## Tokui Waza identity and consistent weight — November 7, 2026

Reference symbols are Red 赤, Blue 青, Orange 橙, Saiyan 緑, Black 黒 and
Namekian 瑪. The 366 other styled cards were checked against their original
Mastery references and live previews; see `tools/card-corrections/v3-namekian-stroke-match/other-styles-audit.json`.

Namekian uses `tools/card-templates/v3/assets/style-symbols/namekian-strokes.svg`
and `scripts/namekian_symbol.py`: the same rounded KanjiVG stroke family as
Blue, Orange, Saiyan and Black, with colored stroke width 7.69230769 and
outline width 13 before normalization to 130-unit outlined height. Keep teal
#21aaa5, center (100,908.5) and the enlarged Mastery placements unchanged.
The previous Noto Bold 瑪 outline had the correct identity but the wrong visual
weight and square terminals. Do not restore it. The earlier 龍 and 無 marks
also remain superseded. Preserve all pixels outside the symbol/backing delta.
Keep all previous audits immutable and follow the reversible revision chain.
Future cards must use the corrected shared Trunks #7 donor and builder.
KanjiVG assets carry their source attribution and CC BY-SA 3.0 license.

## Personality stage order — November 7, 2026

Every Personality stage column prints the highest value at the top and zero
at the bottom. Use `tools/card-templates/v3/scripts/personality_stages.py`
to normalize either source-array orientation; reject unordered input. The
22-card correction and all-172 audit are recorded in
`tools/card-corrections/v3-personality-stages/release.json`. Preserve all
non-stage pixels in both export sizes and the reversible native edit chain.
Android Saga #116's original scan confirms 399,000 instead of 499,000; keep
its catalog, Arena chart and source input synchronized. Historical audits
remain immutable and are checked through the explicit stage revision.

## Cell Games banner emblem — November 6, 2026

All 100 Cell Games cards use the approved banner emblem in both display and download images. Read `tools/card-corrections/v3-cell-games-banner-logo/README.md` and `release.json`. This revision follows the title-width update; preserve the existing titles and all pixels outside the emblem footprint. Keep the visible centers and width recorded in the release. The five final cards retain their missing complete native-source status; their footer delta was validated against a matching native donor. Earlier satin-emblem, artwork and title audits remain immutable.

## Title width, centering and physical card silhouette — November 6, 2026

The approved title paint uses the same horizontal mapping as its own footer, retaining the title’s y12–146 height. Keep the middle bar unchanged. Use `tools/card-templates/v3/scripts/title_width_v3.py`; center complete title ink horizontally at (canvas width−1)/2, and the visible letters/digits vertically at y79, excluding punctuation. Personality titles remain centered on the full bar at x529.5, never on the remaining space beside LEVEL. Retain current font sizes, uniform proportions, 640-unit maximum, stricter existing per-title limits and at least 40-unit LEVEL clearance. Do not move LEVEL.

The isolated revision and reversible native edits are recorded in `tools/card-corrections/v3-title-footer-width/release.json` when applied. Keep earlier audits immutable and follow the explicit title before/after chain. All changes to both existing lossless exports must remain within the native title paint/text delta. The five Cell Games source gaps are reconstructed and verified as **headers only**, not recovered complete native cards. The shared 3D viewer clips circular corners at 5% of the short side, with stock depth 1.25% of the short side (slightly increased from 1.1% at the user’s request; still thinner than the 1.5% preview). Corner clipping does not alter exported artwork pixels.

## Cell Games #30 Goku correction — November 5, 2026

Strength Training shows Super Saiyan Goku and Gohan wearing Saiyan armor, not Vegeta and Trunks. The original production review misidentified the characters. Preserve the isolated native Goku head/neck insert and original artwork beneath it. Current source/export hashes and protected-pixel checks are in `tools/card-corrections/cell-games-030-goku/release.json`. Historical batch and emblem audits stay immutable; follow the subsequent artwork revision chain. The card layout, Gohan, stance, armor, rules, rarity and emblem are unchanged.

## Cell Games final five publication — November 5, 2026

Cards 70, 72, 73, 81 and 83 are now included using the exact approved display/download exports. Cell Games 001–100 has no gaps. Read `tools/card-corrections/v3-cell-games-final-five/README.md` and `release.json` for immutable hashes and recovery provenance. Preserve #72’s rocky-background Goku and #81’s Red Energy Gathering Drill title. The earlier 95-card production/logo audits below are historical. The interrupted upload did not retain these five native SVGs or final native-render audits; expected native Git blob IDs are recorded for future recovery. Do not claim those sources were recovered or rerender/alter the approved exports without recovering or reconstructing verified native sources.

## Personality Level numerals

Use the retained Level paths and placement in `tools/card-templates/v3/assets/text/personality-levels.json` for both the visible numeral and its shadow. Cell Saga Goku #135 is the Level 4 reference. Verify the Level and printed card number against the card's own source record. For the 23 revised cards, follow `level_numeral_revision` in their batch audits for the image and source hashes.

## Cell Games emblem — November 4, 2026

All 95 published Cell Games cards use the approved green wreath/gray hexagon/black C with the Android emblem’s satin finish. Read `tools/card-corrections/v3-cell-games-logo/README.md`; reuse its retained asset and clipped native group for future cards. Keep portrait/landscape visible centers and width unchanged. Historical production audits remain immutable; current source/export hashes follow `release.json`. Five artwork-held cards remain unpublished.

## Cell Games Saga 051–100 — November 4, 2026

This batch adds 45 V3 cards, with native sources in `tools/card-templates/v3/cell-games-051-100/` and complete 50-card source/CRD records in `tools/card-corrections/v3-cell-games-051-100/`. **70, 72, 73, 81 and 83 remain unpublished awaiting artwork**, because the image generator blocked both attempts; the reviewed original scans are unsuitable as clean replacements. Preserve that explicit gap; do not call the batch complete. No Sensei occur in this range. Both Cell Jr. personalities retain Level 1, PUR 2 and eleven printed stages. Locations 79/100 are landscape. Rarity changes from three to five stars at 93. Preserve 52's corrected side kick, 56's corrected distant figure count, 63's 730-unit title width, 58/99's one-copy restrictions, 61's 4 life cards plus 2 stages, 65's removed banishment, 94's overlay permission and 97's broad Setup-or-Drill scope. The 45 reviewed display/download pairs have independent native-render checks. Five held cards retain their transcriptions and CRD work for continuation.

## Cell Saga complete — November 3, 2026

All 160 Cell Saga cards use current V3. Final native sources are in `tools/card-templates/v3/cell-151-160/`, with original scans, CRD, artwork, power-stage, foil-mask and independent render evidence in `tools/card-corrections/v3-cell-151-160/`. Preserve five-star rarity through #156 and six stars on #157–160. The three final Hero Personalities retain all thirteen printed stages, Level/PUR and current blue bars. #157 retains the approved October 28 eight-character user JPEG and uniform framing; do not substitute the unfinished old archive artwork. #153 is no longer Restricted; #155 causes Ally stage loss, not damage. The four Ultra Rare masks are reviewed and pinned to the new image revisions. Both lossless exports match native renders.

## Cell Saga 101–150 — November 3, 2026

Cell cards 101–150 use current V3. Native sources are in `tools/card-templates/v3/cell-101-150/`, with original scans, CRD, artwork and independent export evidence in `tools/card-corrections/v3-cell-101-150/`. Preserve three-star rarity through #111 and five stars from #112, the retained Cell emblem, fixed native text and mirrored footer centers. All twelve Personalities retain their independently verified Level/PUR/stages, including Bulma #109’s printed 2,100 and the thirteen-row columns on #127/#132/#134–138. The six Masteries use the approved November 1 pointed window and continuous Shenron surround. Dende Dragon Balls #121/#122 retain approved full-art bytes and identity mapping, with six-/seven-star left orbs. #110 includes the missing modern POWER prefix; #116/#125/#130/#147 retain their CRD rulings. Preserve #106’s unresolved broad “Combat cards” wording; do not silently narrow it to Events. Both lossless resolutions are independently verified, and per-card scan limitations remain explicit. Cell completion is documented above.

## Cell Saga 051–100 — November 3, 2026

Cell cards 51–100 use current V3. Native sources are in `tools/card-templates/v3/cell-051-100/`, with original scans, CRD, artwork and independent export evidence in `tools/card-corrections/v3-cell-051-100/`. All fifty retain three-star Uncommon rarity and the Cell emblem. Preserve the corrected printed categories: Black Dodge #51 is Physical Combat; Ally Rescue #83 is Setup. The eleven Personalities retain original Level/PUR/stages; Android 19 #90/#95/#98 have thirteen rows including zero, within the same column footprint. Dende Dragon Balls #73–75 keep the approved full-art illustration and identity mapping, with three/four/five-star left orbs. Earlier artwork corrections on #67/#98 remain byte-identical. Both lossless resolutions match independent native renders. Fine original-scan details remain explicitly unresolved per card. Later Cell migrations are documented above.

## Ultra Rare live foil — November 3, 2026

All 17 Ultra Rares use the approved brushed reflective finish in the shared Cards, Decks and Arena enlarged viewer. Read `docs/ultra-rare-foil.md` before changing the effect. Preserve 1.8× brush strength, original colours, reflective black bars, clear rules/white text, natural aura edges without an embossed rim, and the existing Hi-Tech path. Select by catalog rarity; Saiyan 247–250 have their confirmed missing labels restored. Artwork and download rasters remain unchanged. Subject masks are pinned to exact artwork revisions and must be reviewed when art changes.

## Cell Saga 001–050 — November 3, 2026

Cell cards 1–50 now use current V3. Native sources are in `tools/card-templates/v3/cell-001-050/`, with source, artwork, CRD and independent export evidence in `tools/card-corrections/v3-cell-001-050/`. Preserve one-star rarity for 1–40 and three stars for 41–50, the retained Cell emblem, fixed native text and mirrored footer centers. Keep #1’s clipped backdrop-fleck cleanup and #47’s isolated lower-fist insert beneath the unchanged tail. Earlier approved corrections on #20/#36/#42 remain byte-identical. #39/#40 retain the approved full-art Dende summoning pose with identity mapping and single left one-/two-star orbs. Both lossless resolutions match independent native renders, every rules line is visible, and no pixels outside either repair footprint changed. Fine original-scan details remain explicitly unresolved per card. Later Cell migrations are documented above.

## Android Saga 051–100 — November 3, 2026

Android cards 51–100 now use current V3. Native sources are in `tools/card-templates/v3/android-051-100/`, with evidence in `tools/card-corrections/v3-android-051-100/`. Preserve three-star rarity for 51–88 and five stars for 89–100, the RR emblem, fixed native text and mirrored footer groups. Cards 92–96 use the approved landscape master. Preserve #65’s clipped clenched-teeth correction and #76’s approved replacement illustration, including its documented tiny native ground continuation where the old badge covered the recovered image. The old archive’s #76 scan is obsolete. Current CRD rulings and all unresolved original-scan details are retained per card. Later Android cards keep their existing versions.

## Android Saga 001–050 — November 2, 2026

The first fifty Android cards use current V3; sources are in `tools/card-templates/v3/android-001-050/` and review/export evidence in `tools/card-corrections/v3-android-001-050/`. Cards 7/8/43/44 retain the approved landscape master described in `tools/card-templates/v3/references/landscape-v3.md`. Preserve original one-star rarity for 1–36 and three stars for 37–50, the retained RR set emblem, native fixed text, and mirrored footer groups. Keep the clipped artwork corrections on 20/34/37/39 and the approved #38 expression. #24 applies only during the current Combat; #44 includes Dende Dragon Balls. Both lossless exports and correction-mask boundaries are independently verified. Per-card scan limitations remain explicitly unresolved. Later Android cards retain their existing versions.

## Trunks Saga complete — November 2, 2026

All 210 Trunks cards (1–200 and P1–P10) now use V3. Final promo sources and evidence are in `tools/card-templates/v3/trunks-p6-p10/` and `tools/card-corrections/v3-trunks-p6-p10/`. Preserve their two-star promo balls, fixed Freestyle/Setup/Physical Combat components, mirrored footer centers, and lossless exports. P6 and P10 have sky-only corrections; P8 restores Trunks's long-sleeved jacket and Goku's Yardrat outfit with protected original face/hand cores; P9 restores the small sweat drop and pale backdrop. Retain Showdown's broad prohibition on all Ally uses, including takeover, costs, powers, and redirected damage, as recorded in the supplied CRD. Fine details obscured in the original scans remain explicitly unresolved in the per-card artwork review.

## Hero middle-bar blue — November 2, 2026

All 73 current V3 Hero personalities, including Hi-Tech, use the approved reference-blue gradient: `#258bc9` at the top to `#15639d` at the bottom. Read `tools/card-templates/v3/references/hero-middle-blue.md`; preserve grain, transparent brush ends, current title spacing, HERO paths, PUR, artwork and all unrelated components. The color-only release is recorded in `tools/card-corrections/v3-hero-reference-blue/`. Follow each row’s `hero_blue_revision` for current source and export hashes; historical label and title audits remain immutable.

## Personality title clearance and dark Villain bar — November 2, 2026

Read `tools/card-templates/v3/references/personality-title-and-color.md`. Personality titles (including Hi-Tech) use a maximum 640-unit visible width at x209.5–849.5, reduce font size uniformly as needed, and remain visibly centered at (529.5,79). Preserve at least 40 units of LEVEL-number clearance and inspect staggered brush notches. Shorter fitting titles stay unchanged. Villain middle paint is now dark crimson `#a61122`, sampled to match the darker V2 Cell reference, with existing grain/contours and white VILLAIN lettering retained. This supersedes scarlet `#cc2119`. The current repair covers 61 Villain bars and 15 oversized titles across 66 cards; preserve the historical category revision and follow `personality_finish_revision` for current hashes.

# Secondary banner text

The November 2 bolder **Gameplay Discussion** treatment was rejected as too heavy. The forum now uses the original regular Flipside masks and exports in `tools/banner-corrections/gameplay-discussion-fitted-shadow/`, compared directly with the live News / Enter the Arena caption at matched letter height. Do not restore the synthetic bold revision. Preserve original placement, interior distress, solid lower strokes and phrase-fitted shadow; see `tools/banner-corrections/gameplay-discussion-regular-match/README.md` for the comparison.

Navigation hover/current-page feedback uses the established `#c14954` red (`--site-nav-red`). Header wordmarks keep their white ink and use the approved `#b50d1b` (`--site-nav-outline`) outline for hover, keyboard focus and the current page, matching the News action-button red; do not restore gray hover/current-page boxes. Other site navigation uses the same red for hover, focus and selection feedback. The hamburger/close control is the exception: keep its existing two-stroke brush shape and neutral light-grey `#d8dee2` ink in resting, hover, focus, pressed and open states. Do not add hover backgrounds, borders, glow or movement; retain a neutral keyboard-only focus outline. Forum links keep their original underline visibility on hover: do not add hover underlines to titles or navigation, and preserve links that are already underlined in reading content.

The shared navigation is part of normal document flow on desktop and mobile: preserve `position:relative;top:auto`. It must scroll away with the page, with no sticky/fixed replacement. Page anchor and sticky sidebar offsets use a 12px inset rather than reserving the header height.

For future banner captions, taglines and secondary headings, read `tools/banner-templates/secondary-text/README.md` and use its reusable renderer and `style.json`. The approved standard is actual Flipside at its original weight, with solid lower letter strokes and a soft shadow generated from the exact current words. Never add synthetic bold, fade the letter bottoms, or reuse an old phrase's shadow. Preserve unrelated artwork, logos, layout and pixels. The approved reference is the Gameplay Discussion fitted-shadow revision; primary logo typography remains separate.

## Personality middle labels — November 2, 2026

The original 134 V3 Personalities (49 Saiyan, 24 Frieza, 61 Trunks, including Hi-Tech) use only `HERO` or `VILLAIN` in the middle bar. Preserve Michroma 38.4, four-unit tracking, weight, and visible center (529.5,908.5). Use the fixed `hero.svg` / `villain.svg` components. `middle_label_v3.py` maps former long labels to these components; gameplay category data remains unchanged.

The label-only revision is recorded in `tools/card-corrections/v3-personality-short-labels/`. Both existing export sizes are independently patched losslessly, with zero changed pixels outside the old/new label ink and antialias footprint. Artwork, titles, stages, rules, colors, PUR and footers remain unchanged. Preserve historical artwork/footer audits and follow the current audit row's `category_label_revision` before/after hashes. Do not rerender whole published cards for this repair. Verify idempotence with `python3 tools/card-templates/v3/patch_personality_labels.py <work> --apply`; current files remain byte-identical.

# Card production

Cell Games Saga 001–050 are newly added in current V3, with evidence in `tools/card-corrections/v3-cell-games-001-050/` and native SVGs in `tools/card-templates/v3/cell-games-001-050/`. There are no Sensei in this range. Commons #1–31 use one star; Uncommons #32–50 use three. Preserve the green wreath/C Cell Games emblem, #11's corrected background figure count, #15's corrected artwork aspect ratio, #36's bare Goku hand/blue wristband, and #24's 730-unit title safe width. The supplied Expanded CRD review records #8's restrictions, #16's non-action timing and #38's removed banishment sentence. Original effects and source-scan limitations remain per card. Both export sizes independently match the final native render; new set routes and deck-code round trips are covered by tests. Historical V2 typography audits retain their original membership rather than being expanded to cover these new V3 cards.

Trunks Saga 156–200 and P1–P5 now use current V3; evidence is in `tools/card-corrections/v3-trunks-156-200-p1-p5/`. Preserve the separate approved #159 hand/wrist/cuff layer, #166 close framing, #192 reaching pose and corrected top stages 1,200,000/1,100,000, and #195 white armor/blue sleeves. New native masks retain expression repairs on #156/#165/#200, distant onlookers on #172, sky repairs on #185/#186/#189/P2/P3/P4, and Hi-Tech foreground/costume repairs on #191/#196/#197/#199. Keep all 43 original Personality value sets, the bold 4/5 numeral outlines, six-star rarity on #156–160, four stars on #161–200, and two stars on P1–P5. The CRD timing for Goku #164/#165 and separate shield/constant text on #166 are recorded. Both lossless exports and all repair masks are independently verified; original-scan limitations remain per card.

Trunks Saga 106–155 now use current V3. Evidence is in `tools/card-corrections/v3-trunks-106-155/`. Masteries #144–149 use the approved November 1 Mastery source with inset side borders and continuous Shenron surround; preserve #149’s already-published asymmetric tooth-showing smirk layer. Preserve the approved frontal Porunga on #113/#114/#136 at unchanged scale/colors. The twelve personalities retain original Level/PUR/stages, including corrected Dodoria PUR 2/1 on #109/#110 and native bold 4/5 outlines. #133 places cards on the bottom of the Life Deck; #129 has no invented deck limit. Rarity is two stars for #106–111, three for #112–155. All use mirrored footer centers, fixed native text and lossless exports. Fine source-scan limitations are recorded per card.

Trunks Saga 056–105 now use V3; evidence is in `tools/card-corrections/v3-trunks-056-105/`. Preserve #58’s restored victim, #89’s corrected Goku hand, and #79/#80’s approved frontal Porunga with both completed hands and unchanged full-art scale/colors. All fifty retain two-star Uncommon rarity. The six Villain Personalities #100–105 use their original Level/PUR/stages, red power-box corners and fixed native text. All use the mirrored footer anchors. Masteries occur later; use `references/mastery-v3.md` when reached.

Trunks Saga 006–055 now use current V3, with evidence in `tools/card-corrections/v3-trunks-006-055/`. The native Namekian V3 donor is #7: retain the established teal-green background hue, native 瑪 glyph without a circle, and matching rules-box corner accents; all common V3 coordinates remain unchanged. Preserve #25’s approved frontal Porunga at its existing full-art scale/colors and #52’s recorded open-mouth patch. #40 retains its earlier corrected tight portrait crop. The original scan for #25 reads “top 2 cards” from the discard pile; earlier source/catalog text saying 3 was a transcription error, now corrected. Commons #6–40 retain one-star rarity; #41–55 retain two stars. All 50 use the mirrored footer anchors. Later Masteries must use `references/mastery-v3.md`; there are none in this batch.

Trunks Saga 001–005 use current V3; evidence is in `tools/card-corrections/v3-trunks-001-005/`. Preserve the native Trunks double-C emblem at its existing 54-unit height, centered by visible ink at (211.75,1409.5), and the complete rarity/number group at (847.25,1409.5) with a 12.2-unit gap. Namek Dragon Ball 2 retains the approved current front-facing Porunga, both completed hands, unchanged full-art scale/colors, and the V3 single-left two-star orb; do not restore the older overhead Porunga. The five original scans are identity-checked; the retained archive's unrelated Frieza provenance manifest is explicitly excluded. For later Trunks Mastery cards, read `tools/card-templates/v3/references/mastery-v3.md` and resolve the approved November 1 native Mastery source, never an older layout. No Mastery cards occur in 001–005.

V3 footer standard (November 1): center the visible set logo at x211.75 and the complete rarity-ball-plus-card-number group at x847.25, mirrored around the endorsement center x529.5. Preserve sizes, y1409.5 alignment, the 12.2-unit inner ball/number gap, and rarity stars. Use `tools/card-templates/v3/scripts/footer_spacing.py` for every V3 family. For new-card composition after replacing number glyphs, pass `--normalize-gap`; for localized spacing repairs preserve the existing gap. Require byte-idempotence and zero pixel changes outside the old/new footer ink and antialias footprint in each published resolution independently. All 257 Saiyan cards (001–250 and P1–P7) are migrated in `tools/card-corrections/v3-saiyan-001-050-footer-centering/` and `tools/card-corrections/v3-saiyan-051-100-footer-centering/`, and `tools/card-corrections/v3-saiyan-101-150-footer-centering/`, and `tools/card-corrections/v3-saiyan-151-200-footer-centering/`, and `tools/card-corrections/v3-saiyan-201-250-promos-footer-centering/`; Frieza 001–050 are also migrated in `tools/card-corrections/v3-frieza-001-050-footer-centering/`. Other cards retain their previous spacing until separately requested. Keep historical title-only audits immutable and follow the footer revision’s before hashes when verifying that history.

V3: All 257 Saiyan Saga cards (001–250 and P1–P7) now use the approved brush-theme masters. Read `tools/card-templates/v3/README.md` before any V3 edit. Preserve the native V3 coordinates, outlined fonts, genuine brush transparency, and shared title/category/rules/footer geometry. Do not run V2 title or category finalizers on V3. V3 release evidence is in `tools/card-corrections/v3-saiyan-001-050/audit.json`, `tools/card-corrections/v3-saiyan-051-100/audit.json`, and `tools/card-corrections/v3-saiyan-101-150/audit.json`; The additional 151–170 migration is recorded in `tools/card-corrections/v3-saiyan-151-170/audit.json`. Titles retain nominal Teko SemiBold size unless they need uniform reduction to fit a maximum 760-unit width. Center the complete visible ink, including descenders, at (529.5,79); retain measured per-title brush-notch clearance and Personality LEVEL clearance. The title-only repair evidence is in `tools/card-corrections/v3-saiyan-001-170-titles/`. Patch display and download independently, require zero pixel changes outside the old/new lettering and its antialias footprint, and leave already-correct sources and exports byte-identical. `tests/card-v3.test.js` verifies display/download exports and their native sources. `templateVersion: 3` explicitly distinguishes migrated cards; all others retain their established version.

## Retained V2 cards

For every new or revised card, read `tools/card-templates/shared/typography.md`. Titles now use Teko SemiBold at 77.43142144638405 native units (10% smaller), with the visible lettering vertically centered at y72. Apply `tools/card-templates/shared/title_typography.py` after other title operations and require idempotence. Preserve approved horizontal centers, the minimum Personality LEVEL clearance, wording and unrelated pixels. This supersedes older title size/baseline rules. Power text remains Barlow Condensed Bold at 49 with normal spacing and the approved inline-icon gaps. Keep all catalog cards covered by the title and power export audits.

For any new or revised Main Personality or Hi-Tech card, read `tools/card-templates/main-personalities/category-typography.md`. Use the retained compact Hero/Villain vector labels; Saiyan P3 Vegeta's silver variant is the Villain reference. Run `lock_personality_category.py` after other layout/category operations and before export. Never substitute the general category typography or fit these labels to a different width.

Verify both the display image and high-resolution download, including shape, weight, spacing, dimensions and center. Preserve all unrelated pixels during a typography repair and leave already-correct exports byte-identical. Keep all current personalities covered by the category export audit; `npm test` rejects missing or stale verification. Do not update audit hashes without inspecting and measuring the final exports.


The 171–220 migration is recorded in `tools/card-corrections/v3-saiyan-171-220/`, including retained Hi-Tech portraits and per-card original/CRD review. Cards 001–220 now use V3; the 001–170 title-only repair remains an independent immutable audit.

The complete set release is recorded in `tools/card-corrections/v3-saiyan-221-250-promos/`. Apply `scripts/personality_middle_v3.py` to all V3 Villains and Hi-Tech personalities: scarlet `#cc2119` with neutral grain; Hi-Tech gets the native soft silhouette behind the middle brush to prevent artwork/foil-colored streaks showing through. The user-requested Hi-Tech exception preserves the existing middle clip and texture and does not introduce a rectangular backing. For a localized middle-bar repair, preserve every published pixel outside y849–968, including antialiasing. Evidence is in `tools/card-corrections/v3-personality-middle-bars/`; historical title-only audits remain immutable.

Frieza Saga 001–010 now use current V3, with evidence in `tools/card-corrections/v3-frieza-001-010/`. The Frieza emblem is native white vector ink centered at (211.75,1409.5), measured from stroked bounds and scaled uniformly to 53.7814 units wide. Reuse this footer slot for the next Frieza batch. Preserve #4’s approved green/yellow tonal background and isolated old-badge cleanup, and #7’s original closed-mouth correction.

Frieza Saga 011–060 now use current V3, recorded in `tools/card-corrections/v3-frieza-011-060/`. Preserve the twelve verified Personality LEVEL/PUR/stage sets and Guldo #45’s native front-eye correction. All fifty retain the same stroked-ink Frieza footer center (211.75,1409.5). Both display and download are lossless and independently checked. The next migrated range is documented below.

Read `tools/card-templates/v3/references/fixed-native-text-and-villain-corners.md`. The 24 V3 Villains in the earlier repair use red power-box corners, including Hi-Tech. Use the retained native text SVGs and validate shared visible-ink anchors before export; current text and artwork must remain unchanged during localized repairs. Evidence is in `tools/card-corrections/v3-villain-red-corners/`. Retain historical title and middle-bar audits; follow the recorded before/after revision chain instead of rewriting historical hashes.

Frieza 001–050 now retain the current mirrored footer side-group centers in both published image sizes. Use `python3 tools/card-templates/v3/patch_footer_001_050.py <work> --set frieza --range 001-050` for an idempotent verification. Preserve the first-batch artwork corrections, Guldo #45’s eye patch, fixed native text, and all red Villain corner decals. The 001–010 and 011–060 production audits retain the footer revision chain; original rendering audits remain immutable. Cards 051–060 now also use the current spacing, with independent pixel verification in `tools/card-corrections/v3-frieza-051-060-footer-centering/`.

Frieza 051–100 release: 051–060 receive only the mirrored footer repair; 061–100 migrate to current V3 with fixed native SVG text and footer centers. Evidence is in `tools/card-corrections/v3-frieza-051-100/`. Preserve the sky-only corrections on 85/87/97/100, Vegeta 89’s corrected raised-arm pose, and Nail 96’s existing expression patch. All eight Personality levels/PUR/stage sets and all fifty cards’ original artwork/current CRD were reviewed; per-card notes retain unresolved fine details from small source scans. The three new Villains inherit red power-box decals. Frieza completion is documented below.

Frieza Saga is complete in V3: 001–125 plus P1–P11 (136 cards). The final 36 are recorded in `tools/card-corrections/v3-frieza-101-125-promos/`; native sources are in `tools/card-templates/v3/frieza-101-125-promos/`. Preserve #125 Super Saiyan Goku’s explicitly approved rear-facing alternate artwork, including the retained current published refinement layer; NEVER substitute the old front-facing art from older source archives. Its recovered native rear-view background fills only areas previously hidden by the old UI. Preserve P11’s raised-corner smirk patch. All four new Personality game-value sets are populated from their own original scans; #124 uses red Villain corner decals. The final 36 use current footer anchors, fixed native category SVGs and lossless display/downloads. Individual artwork notes explicitly record unresolved fine details in small/foil-obscured source scans.

Android Saga is complete in current V3: all 136 cards, including 101–125 and P1–P11. New evidence is in `tools/card-corrections/v3-android-101-125-promos/`. The ten Android Personalities use the same short labels, fixed text, Hero reference blue and dark Villain crimson; preserve all original Level/PUR/stages, including Android 17’s 399,000 correction and Level 4 outlines. Preserve #118’s exact approved mouth patch and the five isolated sky repairs on #102/#106/#111/#114/#115. Rarity is five stars through #123, six on #124–125, and two on promos. P4 Krillin’s Search has the CRD Restricted List one-copy limit; P2 returns Hero cards to the top; #112 has no banishment. P10 remains landscape. Both exports match native renders and no pixels outside each sky mask were altered by those repairs. Source-scan limitations remain recorded individually.
